import React, { Component } from "react";
import Constant from "../global/constant_variable";
import WebServiceManager from "../util/webservice_manager";
import style from "../scss/modal/m_db.module.scss";
import cn from "classnames";

class MpTest extends Component {
    constructor(props) {
        super(props);

        this.fileCount=0;
        this.state={
            name:null,
            phone:null,
            viewModal : false,
            filenames:[],
        }
    }


   upload=()=> {
        this.callUploadAPI().then((response)=>{
            console.log(response);
        })
   }

   

   async callUploadAPI(){
        let manager=new WebServiceManager(Constant.serviceURL+"/AddMultiFiles","post");
        let allFile =[];
        
        for(let i=0;i<this.state.filenames.length;i++)
        {
            allFile.push(this.state.filenames[i].filename)
            manager.addBinaryData(this.state.filenames[i].filename,this.state.filenames[i].file);
        }
        
        manager.addFormData("data",{name:this.state.name,phone:this.state.phone,filenames:allFile});
        
        
        let response= await manager.start();// --끝났다
        if(response.ok){
            return response.json();
        }
   }

   increment=()=>{
        let array=this.state.filenames;
        this.fileCount=this.fileCount+1;
        array.push({filename:"file"+this.fileCount,file:null})
        this.setState({filenames:array})
   }

   decrement=()=>{
        let array=this.state.filenames;
        array.pop(array.length-1)
        this.setState({filenames:array})
        this.fileCount=this.fileCount-1;
   }
    render() {
        return (
            <div>
                <table cellSpacing="1" cellPadding="3">
                                              
                    <tr>
                        <th>이름</th>
                        <td><input type="data" placeholder="이름을 입력하세요" onChange={(e)=>this.setState({name:e.target.value})}/></td>
                    </tr>
                    <tr>
                        <th>전화번호</th>
                        <td><input type="data" placeholder="전화번호를 입력하세요" onChange={(e)=>this.setState({phone:e.target.value})}/></td>
                    </tr>
                    
                   
                    <tr>
                        <td colspan='2'>
                        <div className={cn(style.btn)}>
                            <span><button onClick={this.increment}>추가</button></span>
                            <span><button onClick={this.decrement}>삭제</button></span>
                            <span><button onClick={this.upload}>전송</button></span>
                        </div>
                        </td>
                    </tr> 
              </table>
              {this.state.filenames.map((item,i)=><AddFile data={item} key={i}/>)}
              
                        
            </div>
        );
    }
}

class AddFile extends Component{

    constructor(props){
        super(props);
    }
    render(){
        const item=this.props.data;
        return (
            <>
            <tr>
                <th>{item.filename}</th>
                
                <td><input type="file" onChange={(e)=>(item.file=e.target.files[0])}/></td></tr>
            </>
        )
    
    }
}
export default MpTest;