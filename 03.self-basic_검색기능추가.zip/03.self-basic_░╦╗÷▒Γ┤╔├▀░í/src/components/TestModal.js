import React, { Component } from "react";
import style from "../scss/Template.module.scss";
import cn from "classnames";
import { GrClose } from "react-icons/gr";
class TestModal extends Component {
    constructor(props){
        super(props);
    }
    
    render() {
        return(
            <>
            
            <div className={style.modal_bg}>
                <div className={cn(style.modal_div, style.m_db_add)}>
                    <div className={style.m_db_menubar}>
                        <p>팝업 연습</p>
                        <button onClick={this.props.listener}>
                        <GrClose />
                        </button>
                    </div>
                    <h3>{this.props.number}</h3>
                    <th>
                    <div className={style.m_db_btn}>
                        <button onClick={this.props.plus}>+</button>
                    </div>
                    <div className={style.m_db_btn}>
                        <button onClick={this.props.minus}>-</button>
                    </div>
                    
                    </th>

                    
            <tr>
            <div className={style.m_db_btn}>
                <button onClick={this.props.Oksign}>확인</button>
            </div>
            </tr>
            </div>
            </div>
           
            
            </>
        );
    }
}

export default TestModal;