

class Variables {

    //웹서비스 URL 지정
    static serviceURL="http://192.168.1.6/opdsapi";
    


    //DBList 검색항목 리스트
    static getNames() {
        return [
            {value:"All",title:"전체"},
            {value:"김태웅",title:"김태웅"},
            {value:"이상섭",title:"이상섭"}
        ];
    }

    static getPowerTrains() {
        return [
            {value:"All",title:"전체"},
            {value:"내연기관(가솔린/디젤)",title:"내연기관(가솔린/디젤)"},
            {value:"EV",title:"EV"},
            {value:"HEV",title:"HEV"}
        ];
    }

    static getAreas() {
        return [
            {value:"All",title:"전체"},
            {value:"미국",title:"미국"},
            {value:"유럽",title:"유럽"},
            {value:"영국",title:"영국"},
            {value:"호주",title:"호주"},
            {value:"캐나다",title:"캐나다"},
            {value:"한국",title:"한국"}
        ];
    }
   
}

export default Variables;