import React, { Component } from "react";


//< 1 2 3 4> 와 같이 페이지 표시함
class Pagenation extends Component {
    constructor(props) {
        super(props);         
    }

    render() {
        const {itemCount,itemCountPerPage,currentPage,clickListener} = this.props;
        const pages = Math.ceil(itemCount/itemCountPerPage); //filteredContents의 길이를 itemCountPerPage(7)으로 나누면 페이지 갯수를 알 수 있다
        // &lt(< 부등호 표현) //1일때는 버튼을 비활성화 시켜주고 < 표시를 누르면 1페이지씩 줄어들게 만든다
        return (
            <>
                <button onClick={() => clickListener(currentPage - 1)} disabled={currentPage === 1}>&lt;</button> 
                {Array(pages).fill().map((_, i) => <Numbering key={i+1} page={i+1} clickListener={clickListener}/>)}
                <button onClick={() => clickListener(currentPage + 1)} disabled={currentPage === pages}>&gt;</button>            
            </>
        );
    }
}

class Numbering extends Component {
    constructor(props) {
        super(props);
    }

    render() {
        return (
            <>
                <button  onClick={() => this.props.clickListener(this.props.page)}>
                    {this.props.page}
                </button>
            </>
        );
    }
}

export default Pagenation;