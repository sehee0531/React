import React, { Component } from "react";

import Template from "../templates/ui_consistis_template";
import Popup from "../components/Popup";


class PopupPage extends Component {
    render() {
        return (
            <>
                <Template>
                    <Popup />
                </Template>
            </>
        );
    }
}

export default PopupPage;