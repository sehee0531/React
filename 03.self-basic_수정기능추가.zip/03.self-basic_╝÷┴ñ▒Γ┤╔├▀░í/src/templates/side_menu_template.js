import React, { Component } from "react";
import { Link } from "react-router-dom";

import style from "../scss/SideMenubar.module.scss";

class SideMenuBarTemplate extends Component {
    render() {
        return (
            <div className={style.side_wrap}>
                <li className={style.side_menulist}>
                    <ul>
                    <Link to="/">
                        <p>✿ 𝑯𝒐𝒎𝒆 ✿</p>
                    </Link>
                    </ul>
                    <ul>
                    <Link to="/Product">
                        <p> 𝑷𝒓𝒐𝒅𝒖𝒄𝒕</p>
                    </Link>
                    </ul>
                    <ul>
                    <Link to="/UploadProduct">
                        <p>𝑼𝒑𝒍𝒐𝒂𝒅 𝑷𝒓𝒐𝒅𝒖𝒄𝒕</p>
                    </Link>
                    </ul>
                    <ul>
                    <Link to="/UploadImg">
                        <p>𝑼𝒑𝒍𝒐𝒂𝒅 𝑷𝒓𝒐𝒅𝒖𝒄𝒕 (𝑰𝒎𝒈)</p>
                    </Link>
                    </ul>
                    <ul>
                    <Link to="/Details">
                        <p>𝑫𝒆𝒕𝒂𝒊𝒍𝒔 (𝑰𝒎𝒈)</p>
                    </Link>
                    </ul>
                    <ul>
                    <Link to="/Popup">
                        <p>𝑷𝒐𝒑𝑼𝑷</p>
                    </Link>
                    </ul>
                    <ul>
                    <Link to="/AddTest">
                        <p>𝑨𝒅𝒅 & 𝑫𝒆𝒍𝒆𝒕𝒆 (𝑰𝒎𝒈)</p>
                    </Link>
                   
                    </ul>
                    <ul>
                    <Link to="/GetImgIDS">
                        <p>𝒄𝒐𝒎𝒃𝒐𝑩𝒐𝒙</p>
                    </Link>
                    </ul>
                    <ul>
                    <Link to="/SearchIDS">
                        <p>𝒔𝒆𝒂𝒓𝒄𝒉𝑩𝒐𝒙</p>
                    </Link>
                   
                    </ul>
                    <ul>
                    <Link to="/ChangeDelete">
                        <p>Change&Delete</p>
                    </Link>
                   
                    </ul>
                </li>
            </div>
        );
    }
}

export default SideMenuBarTemplate;