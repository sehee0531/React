import React, { Component } from "react";

class TopMenuTemplate extends Component {
    render() {
        return (
            <div>
                <center><h1>♡ 𝑺𝒆𝒉𝒆𝒆 𝑹𝒆𝒂𝒄𝒕 𝑷𝒓𝒐𝒋𝒆𝒄𝒕 ♡</h1></center>
            </div>
        );
    }
}

export default TopMenuTemplate;