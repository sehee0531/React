import React, { Component } from "react";

import Template from "../templates/ui_consistis_template";
import SearchIDS from "../components/SearchIDS";


class GetGoodsPage extends Component {
    render() {
        return (
          <>
            <Template>
              <center><SearchIDS /></center>
            </Template>
          </>
        );
    }
}

export default GetGoodsPage;
