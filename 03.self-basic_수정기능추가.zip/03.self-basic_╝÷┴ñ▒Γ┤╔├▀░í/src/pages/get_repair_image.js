import React, { Component } from "react";

import Template from "../templates/ui_consistis_template";
import Details from "../components/Details";


class GetRepairImagePage extends Component {
    render() {
        return (
          <>
            <Template>
            <center><Details /></center>
            </Template>
          </>
        );
    }
}

export default GetRepairImagePage;
