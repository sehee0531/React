import React, { Component } from "react";

import Template from "../templates/ui_consistis_template";
import ChangeDelete from "../components/ChangeDelete";


class GetImgIDSPage extends Component {
    render() {
        return (
          <>
            <Template>
              <center><ChangeDelete /></center>
            </Template>
          </>
        );
    }
}

export default GetImgIDSPage;
