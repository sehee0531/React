import React, { Component } from "react";

import Template from "../templates/ui_consistis_template";
import Product from "../components/Product";


class GetGoodsPage extends Component {
    render() {
        return (
          <>
            <Template>
              <Product />
            </Template>
          </>
        );
    }
}

export default GetGoodsPage;
