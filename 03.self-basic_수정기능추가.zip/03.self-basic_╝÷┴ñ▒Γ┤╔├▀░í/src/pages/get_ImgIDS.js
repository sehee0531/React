import React, { Component } from "react";

import Template from "../templates/ui_consistis_template";
import GetImgIDS from "../components/GetImgIDS";


class GetImgIDSPage extends Component {
    render() {
        return (
          <>
            <Template>
              <center><GetImgIDS /></center>
            </Template>
          </>
        );
    }
}

export default GetImgIDSPage;
