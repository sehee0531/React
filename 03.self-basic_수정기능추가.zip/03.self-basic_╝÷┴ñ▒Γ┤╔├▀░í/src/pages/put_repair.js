import React, { Component } from "react";

import Template from "../templates/ui_consistis_template";
import UploadProduct from "../components/UploadProduct";


class PutRepairPage extends Component {
    render() {
        return (
          <>
            <Template>
            <center><UploadProduct /></center>
            </Template>
          </>
        );
    }
}

export default PutRepairPage;