import React, { Component } from "react";

import Template from "../templates/ui_consistis_template";
import UploadImg from "../components/UploadImg";


class UploadPage extends Component {
    render() {
        return (
          <>
            <Template>
            <center><UploadImg /></center>
            </Template>
          </>
        );
    }
}

export default UploadPage;