import React, { Component } from "react";
import { BrowserRouter, Route, Routes } from "react-router-dom";

import MainPage from "./pages/main_page";
import GetGoodsPage from "./pages/get_repair";
import PutRepairPage from "./pages/put_repair";
import UploadPage from "./pages/upload_file";
import GetRepairImagePage from "./pages/get_repair_image";
import PopupPage from "./pages/Popup_page";
import MpTestPage from "./pages/mpTest_page";
import GetImgIDSPage from "./pages/get_ImgIDS";
import SearchIDSPage from "./pages/get_search";
import ChangeDelPage from "./pages/changedel_page";

class App3 extends Component {
    render() {
        return (
            <>
            <BrowserRouter>
                <Routes>
                    <Route path="/" element={<MainPage />} />
                    <Route path="/Product" element={<GetGoodsPage />} />
                    <Route path="/UploadProduct" element={<PutRepairPage />} />   
                    <Route path="/UploadImg" element={<UploadPage />} />
                    <Route path="/Details" element={<GetRepairImagePage />} />
                    <Route path="/Popup" element={<PopupPage />} />
                    <Route path="/AddTest" element={<MpTestPage />} />
                    <Route path="/GetImgIDS" element={<GetImgIDSPage />} />
                    <Route path="/SearchIDS" element={<SearchIDSPage />} />
                    <Route path="/ChangeDelete" element={<ChangeDelPage />} />
                </Routes>
            </BrowserRouter>
            </>
        );
    }
}

export default App3;