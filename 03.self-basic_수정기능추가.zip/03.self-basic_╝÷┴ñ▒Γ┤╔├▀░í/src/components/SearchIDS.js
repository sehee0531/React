import React, { Component ,  useState, useCallback } from "react";
import Constant from "../global/constant_variable";
import WebServiceManager from "../util/webservice_manager";
import Pagenation from "../util/pagenation";
import { GrClose } from "react-icons/gr";
import style from "../scss/modal/m_db.module.scss";
import combo from "../scss/modal/m_db.module.scss";
import Variables from "../util/constant_variables";
import cn from "classnames";

//includes함수를 이용하여 검색창에 입력한 이름과 일치하면 일치하는 이름의 리스트만 보여주게 만들어줌
class GetImgIDS extends Component {
    constructor(props) {
        super(props);
        
        
        this.Contents=[];  //모든 users값 가져오는 것
        this.names=Variables.getNames();
        this.itemCountPerPage=7; 
        this.state={
            currentPage:1,      // 현재 페이지 (setCurrentPage()에서 변경됨)
            offset:0,         //현재페이지에서 시작할 item index};
            name: this.names[0].value, //이름, 초기값 All
            filteredContents:[], //DBList (디스플레이 용, 필터 적용된)
        };
    }

    //Pagenation에서 몇페이지의 내용을 볼지 선택 (페이지를 선택하면 현재의 페이지에따라 offset 변경)
  setCurrentPage = (page) => {
    let lastOffset = (page-1)*this.itemCountPerPage;
    this.setState({currentPage:page,offset:lastOffset});
  };

    componentDidMount() {
        this.callGetRepairAPI().then((response) => {
           
            this.Contents=response.users;
            this.setState({filteredContents:response.users})  //처음 전체를 표시해주기 위해 users값들을 다 가져옴
        });
    }

    selectName = (value) => {
        console.log('selected data: ',value);
        this.setState({
            name: value,
        }); 
        this.setState({filteredContents:this.dataFiltering(value)});
        this.setCurrentPage(1); // 검색을 하고 다시 다른 이름으로 검색하려고 했을 때 다시 1페이지로 돌아와야 하므로
    };

    dataFiltering=(name)=> {
        let filteredContents=this.Contents;
    
        filteredContents=filteredContents.filter((content) => {   
            return content.name.includes(name); //includes 자체가 아예 비었을 때 이름이 전부 일치한ㄷ고 생각하여 전체가 뜸
        });    
    
        return filteredContents;
    }
   
    async callGetRepairAPI() {
        let manager = new WebServiceManager(Constant.serviceURL+"/GetUsers");
        let response = await manager.start();
        if(response.ok)
            return response.json();
        else
            Promise.reject(response);
    }

    render() {
        return(
            <>
           
            <div>
            <tr>
            <td>&nbsp;&nbsp;&nbsp;search : <input type="text" onChange={(e) => this.selectName(e.target.value)}></input></td>
            </tr>
            </div>
            <table>
                <thead>
                    <tr>
                        <th>id&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;</th>
                        <th>name&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;</th>
                        <th>phone&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;</th>
                        <th>ImgIDS</th>
                    </tr>
                </thead>                
            </table>
            <table>
                <tbody>
                    {this.state.filteredContents.slice(this.state.offset,this.state.offset+this.itemCountPerPage).map((item)=><GetRepairList item={item}/>)}
                </tbody>
            </table>
            <div>
          <Pagenation itemCount={this.state.filteredContents.length} itemCountPerPage={this.itemCountPerPage} currentPage={this.state.currentPage} clickListener={this.setCurrentPage}/>
        </div>
            </>
        );
    }
}

class GetRepairList extends Component {
    
    constructor(props) {
        super(props);
        this.state={viewModal:false,
                    editname:null,
                    editphone:null}
    }

    editbutton=()=>{
        this.props.item.name=this.state.editname
        this.props.item.phone=this.state.editphone
        this.setState({viewModal:false})
    }

    render() {
        const item = this.props.item;
        return(
            <tr>
                <td>{item.id}&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;</td>
                <td>{item.name}&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;</td>
                <td>{item.phone}&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;</td>
                
               &nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;
                <td><div className={style.btn}>
                        <button onClick={()=>{this.setState({viewModal:true})}}>+</button>
                    </div>
                </td>

                {this.state.viewModal &&(<IDsList item={item} 
                listener={()=>this.setState({viewModal:false})}
                Changename={(e)=>this.setState({editname:e.target.value})} 
                Changephone={(e)=>this.setState({editphone:e.target.value})} 
                editsign={()=>this.editbutton()}/>)}
                
            </tr>
            
        )
    }
}


class IDsList extends Component{
    constructor(props) {
        super(props);
    }

    
    render(){
        return(
            <tr>
                <div className={style.modal_bg}>
                    <div className={cn(style.modal_div, style.m_db_add)}>
                        <div className={style.m_db_menubar}>

                            <p>이미지 보기</p> <button onClick={this.props.listener}><GrClose /></button>
                        
                        </div>
                        name : <input type="text" placeholder={this.props.item.name} onChange={this.props.Changename}></input><br></br>
                        phone : <input type="text" placeholder={this.props.item.phone} onChange={this.props.Changephone}></input><br></br>
                        {this.props.item.imageIDs.map((item,i)=><GetImageList item={item} key={i}/>)}
                        <div className={style.btn}>
                            <button onClick={this.props.editsign}>수정</button>
                        </div>
                    </div>
                </div>
            </tr>
        )
    }
}

class GetImageList extends Component {
    
    constructor(props) {
        super(props);
        this.state={imageURL:null}
    }

    componentDidMount() {
        this.callGetRepairImageAPI(this.props.item).then((response) => {
            this.setState({imageURL:URL.createObjectURL(response)});
        });
    }
    

    async callGetRepairImageAPI(id) {
        let manager = new WebServiceManager(Constant.serviceURL+"/GetUserImage?id="+id);
        let response = await manager.start();
        if(response.ok)
            return response.blob();
    }
    render(){
        return(
            <td>
                
                <img src={this.state.imageURL} width="100px"></img>
                        
            </td>
        )
    }
}
        
    



export default GetImgIDS;