import React, { Component } from "react";
import iphone from "./달.jpg";
class Home extends Component {
    render() {
        return(
            <>
            <center><h3><mark>인제대학교 MDL 프로젝트</mark></h3></center>
            <center><img src={iphone} width="500px"></img></center>
            </>
        );
    }
}

export default Home;