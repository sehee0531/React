import React, { Component } from "react";
import Modal from 'react-modal';

class ChangeDelModal extends Component {
    constructor(props){
        super(props);
    }
    
    render() {
        return(
            <>
            <Modal isOpen={true}>
            이름 : {this.props.name}<br></br>
            상품명 : {this.props.title}<br></br>
            상품설명 : {this.props.content}<br></br>
            가격 : {this.props.price}<br></br><br></br>
            상품사진 : {this.props.sendimg}<br></br>


            <button onClick={this.props.listener}>닫기</button>
            </Modal>
            </>
        );
    }
}

export default ChangeDelModal;