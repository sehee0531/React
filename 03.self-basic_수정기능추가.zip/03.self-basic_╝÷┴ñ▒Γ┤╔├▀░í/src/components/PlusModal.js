import React, { Component } from "react";
import Modal from 'react-modal';

class PlusModal extends Component {
    constructor(props){
        super(props);
    }
    
    render() {
        
        return(
            <>
            <Modal isOpen={true}>
            이름 : <input type="text" placeholder={this.props.item.name} onChange={this.props.Changename}></input><br></br>
            번호 : <input type="text" placeholder={this.props.item.title} onChange={this.props.Changephone}></input><br></br>
            

            <button onClick={this.props.listener}>닫기</button>
            <button onClick={this.props.editsign}>수정</button>
            </Modal>
            </>
        );
    }
    
}

export default PlusModal;