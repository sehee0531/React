import React, { Component } from "react";

import WebServiceManager from "../util/webservice_manager";
import Constant from "../global/constant_variable";

class Product extends Component {

    constructor(props) {
        super(props);

        this.state={goodsContents:[]}
    }

    componentDidMount() {
        this.callGetRepairAPI().then((response) => {
            console.log(response);//response는 json자체       
            this.setState({goodsContents:response.goods});
        });

    }

    async callGetRepairAPI() {
        let manager = new WebServiceManager(Constant.serviceURL+"/GetGoods");
        let response = await manager.start();
        console.log(response);//헤더포함한 response message
        if(response.ok)
            return response.json();
        else
            Promise.reject(response);
    }

    render() {
        return(
            <>
            <table>
                <thead>
                    <tr>
                        <th>작성자&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;</th>
                        <th>상품명&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;</th>
                        <th>상품설명&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;</th>
                        <th>가격</th>
                    </tr>
                </thead>                
            </table>

            <table>
                <tbody>
                    {this.state.goodsContents.map((item,i)=><GetRepairList item={item} key={i}/>)}
                </tbody>
            </table>
            </>
        );
    }
}

class GetRepairList extends Component {
    constructor(props) {
        super(props);
    }

    render() {
        const item = this.props.item;
        return(
            <tr>
                <td>{item.name}</td>
                <td>{item.title}</td>
                <td>{item.content}</td>
                <td>{item.price}</td>
            </tr>
        )
    }
}

export default Product;
