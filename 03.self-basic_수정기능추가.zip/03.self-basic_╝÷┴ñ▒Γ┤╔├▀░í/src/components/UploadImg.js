import React, { Component } from "react";
import Constant from "../global/constant_variable";
import MainPage from "../pages/main_page";
import { Alert, Button } from "react-bootstrap";
import WebServiceManager from "../util/webservice_manager";
import style from "../scss/modal/m_db.module.scss";


class UploadImg extends Component {
    constructor(props) {
        super(props);

        this.state={
            name:null,
            title:null,
            content:null,
            price:null,
            file1:null,
            file2:null,
            alertShow:false
        };
    }

    uploadFile=() => {
        console.log(this.state);
        this.callUploadFileAPI().then((response) => {
            console.log(response);
            if(response.count>0) {
                this.setState({alertShow:true});
            }

        });
    }

    async callUploadFileAPI() {
        let manager = new WebServiceManager(Constant.serviceURL +"/AddGoods","post");
        manager.addFormData("data",{name:this.state.name,title:this.state.title,content:this.state.content,price:this.state.price});
        manager.addBinaryData("file1",this.state.file1);
        manager.addBinaryData("file2",this.state.file2);
        let response = await manager.start();
        if(response.ok) //http 200이면
            return response.json(); //받아온 값은 json이다
    }
    
    render() {
        return (
            <>
            
                <table cellSpacing="1" cellPadding="3">
                    <tbody>                              
                 <tr>
                    
                        <th>작성자</th>
                        <td><input type="text" placeholder="작성자를 입력하세요" onChange={(e)=>this.setState({name:e.target.value})}></input></td></tr>
                    <tr>
                        <th>상품명</th>
                        <td><input type="text" placeholder="상품명을 입력하세요" onChange={(e)=>this.setState({title:e.target.value})}></input></td></tr>
                    <tr>
                        <th>상품설명</th>
                        <td><input type="text" placeholder="상품설명을 입력하세요" onChange={(e)=>this.setState({content:e.target.value})}></input></td></tr>
                    <tr>
                        <th>가격</th>
                        <td><input type="long" placeholder="가격을 입력하세요" onChange={(e)=>this.setState({price:e.target.value})}></input></td></tr>
                    <tr>
                    <th>사진1</th>
                    <td><input type="file" onChange={(e)=>this.setState({file1:e.target.files[0]})}></input></td></tr>
                    <tr>
                        <th>사진2</th>
                    <td><input type="file" onChange={(e)=>this.setState({file2:e.target.files[0]})}></input></td></tr>
                    <tr>
                    
                    <div className={style.btn}>
                    <button onClick={this.uploadFile}>전송</button>
                        </div></tr>
                    </tbody>
              </table>
                
                <Alert show={this.state.alertShow} variant="success">
                <Alert.Heading>데이터 업로드</Alert.Heading>
                <p>성공적으로 업로드되었습니다.</p>
                <hr />
                <div className="d-flex justify-content-end">
                    <Button onClick={() => this.setState({alertShow:false})} variant="outline-success">확인</Button></div>
            </Alert>
            </>
        );
    }
}

export default UploadImg;