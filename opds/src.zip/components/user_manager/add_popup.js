import React, { Component } from "react";

import style from "../../scss/modal/m_user.module.scss";
import cn from "classnames";

//props - ({ toggleModal })
class AddUser extends Component {

  constructor(props) {
    super(props);

  }
  render() {
    return (
      <>
        <div className={style.modal_bg}>
          <div className={cn(style.modal_div, style.m_user_add)}>
            <div className={style.m_user_menubar}>
              <p>직원 추가</p>
              <button onClick={this.props.toggleModal}>X</button>
            </div>
            <div className={cn(style.m_user_userinfo)}>
              <div className={cn(style.m_user_input, style.m_user_)}>
                <label>사번</label>
                <input type="text" placeholder="사번을 입력해주세요" />
              </div>
              <div className={cn(style.m_user_input, style.m_user_)}>
                <label>이름</label>
                <input type="text" placeholder="이름을 입력해주세요" />
              </div>
              <div className={cn(style.m_user_input, style.m_user_)}>
                <label>비밀번호</label>
                <input type="text" placeholder="비밀번호을 입력해주세요" />
              </div>
              <div className={cn(style.m_user_input, style.m_user_)}>
                <label>부서</label>
                <select>
                  <option>부서를 선택해주세요</option>
                </select>
              </div>
              <div className={cn(style.m_user_input, style.m_user_)}>
                <label>직급</label>
                <select>
                  <option>직급을 선택해주세요</option>
                </select>
              </div>
              <div className={cn(style.m_user_input, style.m_user_)}>
                <label>권한</label>
                <select>
                  <option>권한을 선택해주세요</option>
                </select>
              </div>
            </div>
            {/* .m_user_userinfo end */}
            <div className={cn(style.m_user_btn, style.m_user_addbtn)}>
              <button>추가</button>
            </div>
          </div>
        </div>
      </>
    );
  }
}


export default AddUser;
