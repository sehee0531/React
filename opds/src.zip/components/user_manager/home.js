import React, { Component } from "react";
import style from "../../scss/UserManage.module.scss";
import cn from "classnames";

import AddUser from "./add_popup";
import EditUser from "./edit_popup";

import { FiEdit } from "react-icons/fi";
import { GoSearch } from "react-icons/go";
import { BiUserPlus } from "react-icons/bi";

class UserManager extends Component {
  constructor(props) {
    super(props);

    this.state = {
      addModal: false,
      editModal: false,
    };
  }
  // 직원 추가 모달
  AddModal = () => {
    this.setState({
      addModal: !this.state.addModal,
    });
  };

  // 직원 정보 수정/삭제 모달
  EditModal = () => {
    this.setState({
      editModal: !this.state.editModal,
    });
  };

  render() {
    return (
      <>
        <div className={style.user_wrap}>
          <div className={style.user_seachaddbtn}>
            <div className={style.user_search}>
              <input type="search" />
              <button title="검색">
                <GoSearch />
              </button>
            </div>
            <div className={style.user_addbtn}>
              <button onClick={this.AddModal} title="직원 추가">
                <BiUserPlus /> 직원 추가
              </button>
              {this.state.addModal && <AddUser toggleModal={this.AddModal} />}
            </div>
          </div>

          <div className={style.user_uls}>
            <div className={style.user_ul_fix_div}>
              <ul className={style.user_ul_fix}>
                <li>연번</li>
                <li>사번</li>
                <li>이름</li>
                <li>부서</li>
                <li>직급</li>
                <li>권한</li>
                <li>수정/삭제</li>
              </ul>
            </div>

            <div className={style.user_ul_scroll_div}>
              <ul className={style.user_ul_scroll}>
                <li>
                  <ul
                    className={cn(
                      style.user_ul_user,
                      style.user_ul_disableduser
                    )}
                  >
                    <li>1</li>
                    <li>123456789</li>
                    <li>정의현</li>
                    <li>SHOP</li>
                    <li>과장</li>
                    <li>관리자</li>
                    <li>
                      <button onClick={this.EditModal}>
                        <FiEdit />
                      </button>
                    </li>
                  </ul>
                </li>
                {/* row end */}
                <li>
                  <ul
                    className={cn(style.user_ul_user, style.user_ul_activeuser)}
                  >
                    <li>2</li>
                    <li>123456789</li>
                    <li>정의현</li>
                    <li>SHOP</li>
                    <li>과장</li>
                    <li>관리자</li>
                    <li>
                      <button onClick={this.EditModal}>
                        <FiEdit />
                      </button>
                    </li>
                  </ul>
                </li>
                {/* row end */}
                <li>
                  <ul
                    className={cn(style.user_ul_user, style.user_ul_activeuser)}
                  >
                    <li>3</li>
                    <li>123456789</li>
                    <li>정의현</li>
                    <li>SHOP</li>
                    <li>과장</li>
                    <li>관리자</li>
                    <li>
                      <button onClick={this.EditModal}>
                        <FiEdit />
                      </button>
                    </li>
                  </ul>
                </li>
                {/* row end */}
                <li>
                  <ul
                    className={cn(style.user_ul_user, style.user_ul_activeuser)}
                  >
                    <li>4</li>
                    <li>123456789</li>
                    <li>정의현</li>
                    <li>SHOP</li>
                    <li>과장</li>
                    <li>관리자</li>
                    <li>
                      <button onClick={this.EditModal}>
                        <FiEdit />
                      </button>
                    </li>
                  </ul>
                </li>
                {/* row end */}
                <li>
                  <ul
                    className={cn(style.user_ul_user, style.user_ul_activeuser)}
                  >
                    <li>5</li>
                    <li>123456789</li>
                    <li>정의현</li>
                    <li>SHOP</li>
                    <li>과장</li>
                    <li>관리자</li>
                    <li>
                      <button onClick={this.EditModal}>
                        <FiEdit />
                      </button>
                    </li>
                  </ul>
                </li>
                {/* row end */}
              </ul>
            </div>
            {/* .user_ul_scroll_div end */}
          </div>
          {this.state.editModal && <EditUser toggleModal={this.EditModal} />}
        </div>
      </>
    );
  }
}

export default UserManager;
