import React, { Component } from "react";

import style from "../../scss/modal/m_user.module.scss";
import cn from "classnames";
import { Alert, Button } from "react-bootstrap";
import { BiUserX } from "react-icons/bi";


//props - ({ index, data, toggleModal })
class EditUser extends Component {
  constructor(props) {
    super(props);
    this.state = ({
      show: false,
    })
  }
  setShow(param) {
    this.setState({
      show: param
    })
  }
  render() {
    return (
      <>
        <div className={style.modal_bg}>
          <div className={cn(style.modal_div, style.m_user_edit)}>
            <div className={style.m_user_menubar}>
              <p>직원 정보 수정</p>
              <button onClick={this.props.toggleModal}>X</button>
            </div>
            <div className={cn(style.m_user_userinfo)}>
              <div className={cn(style.m_user_input, style.m_user_)}>
                <label>사번</label>
                <input type="text" placeholder="1234567" disabled />
              </div>
              <div className={cn(style.m_user_input, style.m_user_)}>
                <label>이름</label>
                <input type="text" placeholder="김다훈" />
              </div>
              <div className={cn(style.m_user_input, style.m_user_)}>
                <label>비밀번호</label>
                <input type="password" placeholder="비밀번호을 입력해주세요" />
              </div>
              <div className={cn(style.m_user_input, style.m_user_)}>
                <label>부서</label>
                <select>
                  <option value="" disabled selected>
                    부서 01
                  </option>
                  <option>부서01</option>
                  <option>부서02</option>
                  <option>부서03</option>
                  <option>비활성화</option>
                </select>
              </div>
              <div className={cn(style.m_user_input, style.m_user_)}>
                <label>직급</label>
                <select>
                  <option value="" disabled selected>
                    부장
                  </option>
                  <option>과장</option>
                  <option>부장</option>
                  <option>사원</option>
                  <option>비활성화</option>
                </select>
              </div>
              <div className={cn(style.m_user_input, style.m_user_)}>
                <label>권한</label>
                <select>
                  <option value="" disabled selected>
                    레벨 2
                  </option>
                  <option>레벨 1</option>
                  <option>레벨 2</option>
                  <option>레벨 3</option>
                  <option>비활성화</option>
                </select>
              </div>
            </div>
            {/* .m_user_userinfo end */}
            <div className={cn(style.m_user_btn, style.m_user_editbtn)}>
              <button>수정</button>
              <button title="직원 비활성화" onClick={() => this.setShow(true)}>
                <BiUserX />
                {/* 비활성화가 된 상태에서는 아이콘 숨김 */}
              </button>
            </div>
          </div>
        </div>

        <Alert className={style.a_user_alert} show={this.state.show} variant="warning">
          <div className={style.a_user_alerttitle}>
            <p>해당 직원을 비활성화 하시겠습니까?</p>
            <button onClick={() => this.setShow(false)}>X</button>
          </div>

          <Button variant="outline-warning">삭제</Button>
        </Alert>
      </>
    );
  }
}
export default EditUser;
