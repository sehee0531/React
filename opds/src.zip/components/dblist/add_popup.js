import React, { Component } from "react";

import Constant from "../../util/constant_variables";
import WebServiceManager from "../../util/webservice_manager";

import style from "../../scss/modal/m_db.module.scss";
import cn from "classnames";
import { FiArrowRight } from "react-icons/fi";
import { GrClose } from "react-icons/gr";

//props 접근 = ({ index, data, toggleModal })

class AddDB extends Component {
  constructor(props) {
    super(props);
    this.makers=Constant.getMakers();
    this.powers=Constant.getPowerTrains();
    this.areas=Constant.getAreas();

    this.state={
      maker:this.makers[1].value,
      power:this.powers[1].value,
      area:this.areas[1].value,
      asis:'asis',
      tobe:'tobe'
    };
  }

  //DBList 추가 웹서비스 호출
  addProhibitWords=()=> {
    console.log('add prohibit words ',this.state);
    this.callAddDBListWebService().then((response) => {
      console.log(response);
    });
    this.props.okListener();
  }

  textChangedListener=(e)=> {
    if(e.target.name==="asis")
      this.setState({asis:e.target.value});
    else
      this.setState({tobe:e.target.value});
  }

  //DBList 추가 웹서비스
  async callAddDBListWebService() {
    let manager = new WebServiceManager(Constant.serviceURL+"/add_dblist","post");
    manager.addFormData("data",this.state);
    let response = await manager.start();
    if(response.ok)
      return response.json();
  }
  
  render() {
    return (
      <>
        <div className={style.modal_bg}>
          <div className={cn(style.modal_div, style.m_db_add)}>
            <div className={style.m_db_menubar}>
              <p>DB 추가</p>
              <button onClick={this.props.cancelListener}>
                <GrClose />
              </button>
            </div>

            <div className={style.m_db_contents}>
              <div className={cn(style.m_db_select, style.m_db_manufacture)}>
                <label>제조사</label>
                <select value={this.state.maker} onChange={(e)=> this.setState({maker:e.target.value})}>
                    {this.makers.slice(1,this.makers.length).map((item,i) => <option value={item.value} key={i}>{item.title}</option>)}
                </select>
              </div>
              <div className={cn(style.m_db_select, style.m_db_powerspec)}>
                <label>파워트레인 사양</label>
                <select value={this.state.power} onChange={(e)=> this.setState({power:e.target.value})}>
                    {this.powers.slice(1,this.powers.length).map((item,i) => <option value={item.value} key={i}>{item.title}</option>)}
                </select>
              </div>
              <div className={cn(style.m_db_select, style.m_db_location)}>
                <label>지역</label>
                <select value={this.state.area} onChange={(e)=> this.setState({area:e.target.value})}>
                    {this.areas.slice(1,this.areas.length).map((item,i) => <option value={item.value} key={i}>{item.title}</option>)}
                </select>
              </div>

              <div className={cn(style.m_db_select, style.m_db_edithistory)}>
                <label>수정내역</label>
                <div className={style.m_db_history}>
                  <input type="text" name="asis" value={this.state.asis} onChange={this.textChangedListener}></input>
                  <p>
                    <FiArrowRight />
                  </p>
                  <input type="text" name="tobe" value={this.state.tobe} onChange={this.textChangedListener}></input>
                </div>
              </div>

              <div className={style.m_db_btn}>
                <button onClick={this.addProhibitWords}>추가</button>
              </div>
            </div>
          </div>
        </div>
      </>
    );
  }
}

export default AddDB;
