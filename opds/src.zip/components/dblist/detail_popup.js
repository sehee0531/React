import React, { Component } from "react";

import style from "../../scss/modal/m_db.module.scss";
import cn from "classnames";
import { Alert, Button } from "react-bootstrap";
import { FiArrowRight } from "react-icons/fi";
import { RiDeleteBinLine } from "react-icons/ri";
import { GrClose } from "react-icons/gr";

//props - ({ index, data, toggleModal })

class DetailDB extends Component {
  constructor(props) {
    super(props);

    this.state = {
      show: false
    }
  }

  //삭제 클릭시 확인 Alert 보여줄지...
  setShow(param) {
    this.setState({
      show: param
    })
  }

  modifyItem=()=> {
    console.log('modify in DBList Detail :',this.props.item.maker);
    this.props.okListener();
  }

  deleteItem=()=> {
    console.log('delete in DBList Detail :',this.props.item.maker);
    this.setShow(true);
    this.props.okListener();
  }

  render() {
    const item = this.props.item;
    return (
      <>
        <div className={style.modal_bg}>
          <div className={cn(style.modal_div, style.m_db_add)}>
            <div className={style.m_db_menubar}>
              <p>DB 수정 이력</p>
              <button onClick={this.props.cancelListener}>
                <GrClose />
              </button>
            </div>

            <div className={style.m_db_contents}>
              <div className={cn(style.m_db_select, style.m_db_manufacture)}>
                <label>제조사</label>
                <input type="text" placeholder={item.maker} />
              </div>
              <div className={cn(style.m_db_select, style.m_db_powerspec)}>
                <label>파워트레인 사양</label>
                <input type="text" placeholder={item.power} />
              </div>
              <div className={cn(style.m_db_select, style.m_db_location)}>
                <label>지역</label>
                <input type="text" placeholder={item.area} />
              </div>
              <div className={cn(style.m_db_select, style.m_db_edithistory)}>
                <label>수정내역</label>
                <div className={style.m_db_history}>
                  <input placeholder={item.asis}></input>
                  <p>
                    <FiArrowRight />
                  </p>
                  <input placeholder={item.tobe}></input>
                </div>
              </div>

              <div className={cn(style.m_db_btn, style.m_db_editbtn)}>
                <button onClick={this.modifyItem}>수정</button>
                <button title="DB 삭제" onClick={()=>this.setShow(true)}>
                  <RiDeleteBinLine />
                </button>
              </div>
            </div>
          </div>
        </div>

        <Alert className={style.a_db_alert} show={this.state.show} variant="warning">
          <div className={style.a_db_alerttitle}>
            <p>DB를 삭제하시겠습니까?</p>
            <button onClick={()=>this.setShow(false)}>
              <GrClose />
            </button>
          </div>

          <Button onClick={this.deleteItem} variant="outline-warning">삭제</Button>
        </Alert>
      </>
    );
  }
}
export default DetailDB;
