import { React, Component } from "react";

import Constant from "../../util/constant_variables";
import WebServiceManager from "../../util/webservice_manager";
import MyStore from "../../util/redux_store";

import AddDB from "./add_popup";
import DBdetail from "./detail_popup";
import Pagenation from "../../util/pagenation";

import style from "../../scss/DbList.module.scss";
import cn from "classnames";
import { FiPlus } from "react-icons/fi";
import { GrChapterAdd } from "react-icons/gr";


class DBList extends Component {
  constructor(props) {
    super(props);

    this.itemCountPerPage=7;      //Pagenation 관련 한페이지에 표시할 리스트 갯수
    this.contents=[];             //DBList 원본
    this.makers=Constant.getMakers();
    this.powers=Constant.getPowerTrains();
    this.areas=Constant.getAreas();

    this.state = {
      filteredContents:[], //DBList (디스플레이 용, 필터 적용된)
      maker: this.makers[0].value, //제조사 필터링, 초기값 All
      power: this.powers[0].value, //파워트레인 필터링, 초기값 All
      area: this.areas[0].value, //국가 필터링, 초기값 All
      addModal: false, //DB추가 모달
      detailModal: false, //DB상세내역 모달
      selectedIndex:null, //DBList에서 현재 선택된 항목 index 값

      currentPage:1,      // 현재 페이지 (setCurrentPage()에서 변경됨)
      offset:0            //현재페이지에서 시작할 item index
    };
  }

  componentDidMount() {
    this.callDBListWebService().then((response) => {
      this.contents=response;
      //this.setState({filteredContents:this.contents});
      this.setState({filteredContents:this.dataFiltering(this.state.maker,this.state.power,this.state.area)});
    });
  }

  //DBList 웹서비스 호출
  async callDBListWebService() {
    let manager = new WebServiceManager(Constant.serviceURL+"/dblist");
    let response = await manager.start();
    if(response.ok)
      return response.json();
  }

  //Pagenation에서 몇페이지의 내용을 볼지 선택 (페이지를 선택하면 현재의 페이지에따라 offset 변경)
  setCurrentPage = (page) => {
    let lastOffset = (page-1)*this.itemCountPerPage;
    this.setState({currentPage:page,offset:lastOffset});
  };

  //리스트에서 선택된 항목의 index 설정과 모달 박스 보여줄지 말지 결정
  setContentIndex = (index) => {
    this.setState({
      detailModal:!this.state.detailModal,
      selectedIndex:index
    });
  }

  addProhibitWords=()=> {
    this.setState({addModal:false});
    this.callDBListWebService().then((response) => {
      this.contents=response;
      this.setState({filteredContents:this.dataFiltering(this.state.maker,this.state.power,this.state.area)});
    });
  }


  //DB추가 팝업 뛰울지 판단/권한있는지
  verifyAddDB = (e) => { 
    if(MyStore.getState().level===1) {
      this.setState({
        addModal: !this.state.addModal
      });
    }else {
      alert('권한이 없습니다.');
      e.perventDefault();
    }
  }; 

  
  //DB상세내역 모달 (상세보기에서 수정 또는 삭제 버튼을 클릭하면 실행되는 이벤트, DBList Refresh)
  refreshDBList = () => {
    console.log('Refresh DBList in DBList Home');
    this.setState({
      detailModal: !this.state.detailModal
    });
    this.callDBListWebService().then((response) => {
      this.contents=response;
      //this.setState({filteredContents:this.contents});
      this.setState({filteredContents:this.dataFiltering(this.state.maker,this.state.power,this.state.area)});
    });
  };


  

  //검색 - dataFiltering 메서드 호출
  //제조사, 파워트레인, 지역 콤보박스가 뱐경되면 필터적용하고 state.filteredContents값 바꾸고 현재페이는 1로
  selectMaker = (value) => {
    console.log('selected data: ',value);
    this.setState({
      maker: value,
    });
    this.setState({filteredContents:this.dataFiltering(value,this.state.power,this.state.area)});
    this.setCurrentPage(1);
  };

  selectPower = (value) => {
    this.setState({
      power: value,
    });
    this.setState({filteredContents:this.dataFiltering(this.state.maker,value,this.state.area)});
    this.setCurrentPage(1);
  };

  selectArea = (value) => {
    this.setState({
      area: value,
    });
    this.setState({filteredContents:this.dataFiltering(this.state.maker,this.state.power,value)});
    this.setCurrentPage(1);
  };
  ///////////////////////

  //데이터 필터링
  dataFiltering=(maker,power,area)=> {
    let filteredContents=this.contents;

    filteredContents=filteredContents.filter((content) => {   
      console.log('maker selected: ',this.makers[0].value);
      if(maker===this.makers[0].value)  
        return true;
      else
        return content.maker===maker;
    });    

    filteredContents=filteredContents.filter((content) => {     
      if(power===this.powers[0].value)
        return true;
      else
        return content.power===power;
    });   

    filteredContents=filteredContents.filter((content) => {    
      if(area===this.areas[0].value) 
        return true;
      else
        return content.area===area;
    });

    return filteredContents;
  }


  render() {
    return (
      <>
        <div className={style.db_wrap}>
          <div className={style.db_selectbtn}>
            <div className={style.db_selectoption}>
              <div className={cn(style.db_selectform, style.db_manufactor)}>
                <p>제조사</p>
                <select
                  value={this.state.maker}
                  onChange={(e) => this.selectMaker(e.target.value)}>
                  {this.makers.map((item,i) => <option value={item.value} key={i}>{item.title}</option>)}                  
                </select>
              </div>
              <div className={cn(style.db_selectform, style.db_power)}>
                <p>파워트레인 사양</p>
                <select
                  value={this.state.power}
                  onChange={(e) => this.selectPower(e.target.value)}>
                  {this.powers.map((item,i) => <option value={item.value} key={i}>{item.title}</option>)}
                </select>
              </div>
              <div className={cn(style.db_selectform, style.db_location)}>
                <p>지역</p>
                <select
                  value={this.state.area}
                  onChange={(e) => this.selectArea(e.target.value)}>
                  {this.areas.map((item,i) => <option value={item.value} key={i}>{item.title}</option>)}
                </select>
              </div>
            </div>
            <div className={style.db_addbtn}>
              <button onClick={this.verifyAddDB}>
                <GrChapterAdd /> DB 추가
              </button>
              {this.state.addModal && (
                <AddDB okListener={this.addProhibitWords} cancelListener={()=>this.setState({addModal:false})}></AddDB>
              )}
            </div>
          </div>
          {/* .db_selectbtn end */}
          <div className={style.db_tables}>
            <div className={style.db_table_fix_div}>
              <table
                className={style.db_table_fix}
                cellPadding="0"
                cellSpacing="0"
              >
                <thead>
                  <tr>
                    <th>연번</th>
                    <th>제조사</th>
                    <th>파워트레인 사양</th>
                    <th>지역</th>
                    <th>As-is</th>
                    <th>To be</th>
                    <th>상세내역</th>
                  </tr>
                </thead>
              </table>
            </div>
            <div className={style.db_table_scroll_div}>
              <table
                className={style.db_table_scroll}
                cellPadding="0"
                cellSpacing="0">
                <tbody>
                  {/*DB리스트 항목 보여주기*/}
                  {this.state.filteredContents.slice(this.state.offset,this.state.offset+this.itemCountPerPage).map((item,i) => <DBListItem item={item} key={i} index={i} listener={this.setContentIndex}/>)}
                </tbody>
              </table>
              
            </div>
            {this.state.detailModal && (
              <DBdetail item={this.state.filteredContents[this.state.selectedIndex]} okListener={this.refreshDBList} cancelListener={()=>this.setState({detailModal:!this.state.detailModal})}/>
            )}
          </div>
          
          {/* .db_tables end */}
        </div>
        {/*페이징*/}
        <div>
          <Pagenation itemCount={this.state.filteredContents.length} itemCountPerPage={this.itemCountPerPage} currentPage={this.state.currentPage} clickListener={this.setCurrentPage}/>
        </div>
      </>
    );
  }
}

//DBList의 각 항목
class DBListItem extends Component {
  constructor(props) {
    super(props);
  }

  //리스트의 한 아이템이 선택되면 호출되는 이벤드
  onClickListener=()=> {
    this.props.listener(this.props.index);
  }

  render() {
    const item = this.props.item;
    return (
      <tr>
        <td>{item.id}</td>
        <td>{item.maker}</td>
        <td>{item.power}</td>
        <td>{item.area}</td>
        <td>{item.asis}</td>
        <td>{item.tobe}</td>
        <td>
          <button onClick={this.onClickListener} >            
            <FiPlus />
          </button>
        </td>
      </tr>
    )
  }
}

export default DBList;
