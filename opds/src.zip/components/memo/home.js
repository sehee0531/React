import React, { Component } from "react";

import style from "../../scss/Memo.module.scss";
import cn from "classnames";
import { Tab, Tabs, TabList, TabPanel } from "react-tabs";

class Memo extends Component {
  render() {
    return (
      <>
        <div className={cn(style.memoboth_wrap)}>
          <div className={cn(style.memoboth_check, style.memo_check)}>
            <Tabs>
              <TabList className={cn(style.memoboth_tab_ul)}>
                <Tab>전체</Tab>
                <Tab>미확인</Tab>
                <Tab>확인</Tab>
              </TabList>

              <TabPanel>
                <div className={style.memoboth_tables}>
                  <table
                    className={style.memoboth_table_fix}
                    cellPadding="0"
                    cellSpacing="0">
                    <thead>
                      <tr>
                        <th>연번</th>
                        <th>제목</th>
                        <th>등록인</th>
                        <th>등록 날짜</th>
                        <th>상세</th>
                        <th>확인</th>
                        <th>삭제</th>
                      </tr>
                    </thead>
                  </table>
                  <div className={style.memoboth_table_scroll_div}>
                    <table
                      className={style.memoboth_table_scroll}
                      cellPadding="0"
                      cellSpacing="0">
                      <tbody>
                        <tr>
                          <td>1</td>
                          <td>DB 7번 내용 수정 부탁 드립니다.</td>
                          <td>매니저 1</td>
                          <td>2022-01-05</td>
                          <td>
                            <button>+</button>
                          </td>
                          <td>
                            <button>v</button>
                          </td>
                          <td>
                            <button>x</button>
                          </td>
                        </tr>
                        {/* row end */}
                        <tr>
                          <td>2</td>
                          <td>DB 7번 내용 수정 부탁 드립니다.</td>
                          <td>매니저 1</td>
                          <td>2022-01-05</td>
                          <td>
                            <button>+</button>
                          </td>
                          <td>
                            <button>v</button>
                          </td>
                          <td>
                            <button>x</button>
                          </td>
                        </tr>
                        {/* row end */}
                        <tr>
                          <td>3</td>
                          <td>DB 7번 내용 수정 부탁 드립니다.</td>
                          <td>매니저 1</td>
                          <td>2022-01-05</td>
                          <td>
                            <button>+</button>
                          </td>
                          <td>
                            <button>v</button>
                          </td>
                          <td>
                            <button>x</button>
                          </td>
                        </tr>
                        {/* row end */}
                        <tr>
                          <td>4</td>
                          <td>DB 7번 내용 수정 부탁 드립니다.</td>
                          <td>매니저 1</td>
                          <td>2022-01-05</td>
                          <td>
                            <button>+</button>
                          </td>
                          <td>
                            <button>v</button>
                          </td>
                          <td>
                            <button>x</button>
                          </td>
                        </tr>
                        {/* row end */}
                        <tr>
                          <td>5</td>
                          <td>DB 7번 내용 수정 부탁 드립니다.</td>
                          <td>매니저 1</td>
                          <td>2022-01-05</td>
                          <td>
                            <button>+</button>
                          </td>
                          <td>
                            <button>v</button>
                          </td>
                          <td>
                            <button>x</button>
                          </td>
                        </tr>
                        {/* row end */}
                      </tbody>
                    </table>
                  </div>
                </div>
              </TabPanel>
              <TabPanel>
                <h2>Any content 2</h2>
              </TabPanel>
              <TabPanel>
                <h2>Any content 3</h2>
              </TabPanel>
            </Tabs>
          </div>
          {/* .memo_check end */}
        </div>
      </>
    );
  }
}

export default Memo;
