import React, { Component } from "react";

import Constant from "../../util/constant_variables";
import WebServiceManager from "../../util/webservice_manager";
import AddPopup from "./add_popup";
import DetailPopup from "./detail_popup";
import ValidatePopup from "./validate_popup";
import Pagenation from "../../util/pagenation";

import style from "../../scss/ProjectManage.module.scss";
import cn from "classnames";
import { AiOutlineFolderAdd } from "react-icons/ai";

class ProjectManager extends Component {
  constructor(props) {
    super(props);

    this.itemCountPerPage=5;
    this.contents=[];                 //서버에서 가져온 원본 Contents
    this.makers=Constant.getMakers();
    this.powers=Constant.getPowerTrains();
    this.areas=Constant.getAreas();

    this.state = {
      addModal: false,                //프로젝트 추가 팝업 On/Off
      validateModal: false,           //프로젝트 추가 후 확인 팝업 On/Off
      detailModal: false,             //프로젝트 상세보기 팝업 On/Off

      maker:this.makers[0].value,     //검색 필드
      power:this.powers[0].value,     //검색필드
      area:this.areas[0].value,       //검색필드

      filteredContents: [],           //검색 결과 Contents
      selectedItemIndex:null,         //프로젝트 리스트에서 현재 선택된 프로젝트의 index
      newAddData:null,                //AddPopup창에서 입력한 데이터

      currentPage:1,      // 현재 페이지 (setCurrentPage()에서 변경됨)
      offset:0            //현재페이지에서 시작할 item index
    };
  }

  componentDidMount() {
    this.callProjectListWebService().then((response) => {
      this.contents=response;
      this.setState({filteredContents:this.dataFiltering(this.state.maker,this.state.power,this.state.area)});
    });
  }

  async callProjectListWebService() {
    let manager = new WebServiceManager(Constant.serviceURL+"/projectlist");
    let response = await manager.start();
    if(response.ok)
      return response.json();
  }



  //프로젝트 리스트에서 하나의 아이템을 선택하면 DetailPopup창을 띄우고 현재 선택된 아이템의 index 설정
  setItemIndex = (index) => {
    this.setState({
      detailModal: !this.state.detailModal,
      selectedItemIndex:index
    });
  }

   //AddPopup창을 닫고 ValidatePopup창을 띄움
  checkModal=()=> {
    this.setState(
      {addModal:!this.state.addModal,
        validateModal:!this.state.validateModal});
  }

  //AddPopup창에서 입력된 데이터 설정
  setNewAddData=(data)=> {
    this.checkModal();
    this.setState({newAddData:data});
  }


  addProject=()=>{
    this.setState({addModal:false,validateModal:false});  
    console.log('refresh server list');  
    this.callProjectListWebService().then((response) => {
      this.contents=response;
      this.setState({filteredContents:this.dataFiltering(this.state.maker,this.state.power,this.state.area)});
    });
  }

  deleteProject = () => {
    this.setState({detailModal:false});
    console.log('delete2');
    this.callProjectListWebService().then((response) => {
      this.contents=response;
      this.setState({filteredContents:this.dataFiltering(this.state.maker,this.state.power,this.state.area)});
    });
  }


  //Pagenation에서 몇페이지의 내용을 볼지 선택 (페이지를 선택하면 현재의 페이지에따라 offset 변경)
  setCurrentPage = (page) => {
    let lastOffset = (page-1)*this.itemCountPerPage;
    this.setState({currentPage:page,offset:lastOffset});
  };


  //검색 - dataFiltering 메서드 호출
  //제조사, 파워트레인, 지역 콤보박스가 뱐경되면 필터적용하고 state.filteredContents값 바꾸고 현재페이는 1로
  selectMaker = (value) => {
    console.log('selected data: ',value);
    this.setState({
      maker: value,
    });
    this.setState({filteredContents:this.dataFiltering(value,this.state.power,this.state.area)});
    this.setCurrentPage(1);
  };

  selectPower = (value) => {
    this.setState({
      power: value,
    });
    this.setState({filteredContents:this.dataFiltering(this.state.maker,value,this.state.area)});
    this.setCurrentPage(1);
  };

  selectArea = (value) => {
    this.setState({
      area: value,
    });
    this.setState({filteredContents:this.dataFiltering(this.state.maker,this.state.power,value)});
    this.setCurrentPage(1);
  };
  ///////////////////////


  //데이터 필터링
  dataFiltering=(maker,power,area)=> {
    let filteredContents=this.contents;

    filteredContents=filteredContents.filter((content) => {   
      if(maker===this.makers[0].value)  
        return true;
      else
        return content.maker===maker;
    });    

    filteredContents=filteredContents.filter((content) => {     
      if(power===this.powers[0].value)
        return true;
      else
        return content.power===power;
    });   

    filteredContents=filteredContents.filter((content) => {    
      if(area===this.areas[0].value) 
        return true;
      else
        return content.area===area;
    });

    return filteredContents;
  }




  render() {
    return (
      <>
        <div className={style.project_wrap}>
          <div className={style.project_selectbtn}>
            <div className={style.project_selectoption}>
              <div
                className={cn(style.project_selectform, style.project_manufactor)}
              >
                <p>제조사</p>
                <select value={this.state.maker} onChange={(e) => this.selectMaker(e.target.value)}>
                {this.makers.map((item,i) => <option value={item.value} key={i}>{item.title}</option>)}
                </select>
              </div>
              <div className={cn(style.project_selectform, style.project_power)}>
                <p>파워트레인 사양</p>
                <select value={this.state.power} onChange={(e) => this.selectPower(e.target.value)}>
                {this.powers.map((item,i) => <option value={item.value} key={i}>{item.title}</option>)}
                </select>
              </div>
              <div
                className={cn(style.project_selectform, style.project_location)}
              >
                <p>지역</p>
                <select value={this.state.area} onChange={(e) => this.selectArea(e.target.value)}>
                {this.areas.map((item,i) => <option value={item.value} key={i}>{item.title}</option>)}
                </select>
              </div>
            </div>

            <div className={style.project_addbtn}>
              <button onClick={()=>this.setState({addModal:true})} title="프로젝트 추가">
                <AiOutlineFolderAdd /> 프로젝트 추가
              </button>
              {/*프로젝트 추가 팝업*/}
              {this.state.addModal && <AddPopup 
                cancelListener={()=>this.setState({addModal:false})} okListener={this.setNewAddData}/>}

              {/*프로젝트 추가에 대한 확인 팝업*/}
              {this.state.validateModal && <ValidatePopup cancelListener={this.checkModal} data={this.state.newAddData} okListener={this.addProject}/>}
            </div>
          </div>

          {/* .project_selectbtn end */}
          <div className={style.project_divs}>
            {/*프로젝트 상세보기 팝업*/}
            {this.state.detailModal && <DetailPopup 
              cancelListener={()=> this.setState({detailModal:false})} 
              deleteListener={this.deleteProject} item={this.state.filteredContents[this.state.selectedItemIndex]}/>}

            {/*프로젝트 리스트 각 항목 보이기*/}
            {this.state.filteredContents.slice(this.state.offset,this.state.offset+this.itemCountPerPage).map((item,i)=> <ProjectDetailItem item={item} key={i} index={i} listener={this.setItemIndex}/>)}            
          </div>
        </div>

        {/*페이징*/}
        <div>
          <Pagenation itemCount={this.state.filteredContents.length} itemCountPerPage={this.itemCountPerPage} currentPage={this.state.currentPage} clickListener={this.setCurrentPage}/>
        </div>
      </>
    );
  }
}

//프로젝트 리스트에서 하나의 항목
class ProjectDetailItem extends Component {
  constructor(props) {
    super(props);
  }

  onClickListener =() => {
    this.props.listener(this.props.index);
  }

  render() {
    const item = this.props.item;

    return (
      <div className={style.project_div} onClick={this.onClickListener}>
        <div className={style.project_filename}>
          <p>파일명</p>
          <p>{item.origin_filename}</p>
        </div>
        <div className={style.project_filedetails}>
          <table
            className={style.project_filedetails_table}
            cellPadding="0"
            cellSpacing="0"
          >
            <thead>
              <tr>
                <th>제조사</th>
                <td>{item.maker}</td>
              </tr>
            </thead>
            <tbody>
              <tr>
                <th>파워트레인 사양</th>
                <td>{item.power}</td>
              </tr>
              <tr>
                <th>지역</th>
                <td>{item.area}</td>
              </tr>
            </tbody>
          </table>
        </div>
      </div>
    )
  }
}
export default ProjectManager;
