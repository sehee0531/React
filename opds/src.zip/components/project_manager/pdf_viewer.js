import React, { Component } from "react";

import { useLocation, useNavigate, useParams } from 'react-router-dom'
import WebServiceManager from "../../util/webservice_manager";
import Constant from "../../util/constant_variables";

import style from "../../scss/PDFviewer.module.scss";

class PDFViewer extends Component {

  constructor(props) {
    super(props);
    this.state={pdfSrc:null,summary:[]};
  }


  componentDidMount() {
    console.log(this.props.location.state);
    this.setState({pdfSrc:Constant.serviceURL+"/downPDFFile/"+this.props.location.state.filename});

    this.callGetSummaryReportWebService().then((response) =>{
      console.log(response);
      this.setState({summary:response});
    });
  }


  //PDF 관련 웹서비스 
  //PDF파일이름, asis, tobe를 파라메터로 하여 PDF 파일에 대한 요약정보 가져옴
  async callGetSummaryReportWebService() {
    //let body={'filename':item.filename,'asis':item.asis,'tobe':item.tobe};
    //let body={'filename':'test.pdf','asis':item.asis,'tobe':item.tobe};
    let manager = new WebServiceManager(Constant.serviceURL+"/getSummaryReport/"+this.props.location.state.filename);
    //manager.addFormData("data",body);
    let response = await manager.start();
    if(response.ok)
      return response.json();
  }
  // PDF 관련 웹서비스 끝


  

  errorEventListener=(e) => {    
    alert('네트워크 오류');
    e.preventDefault();
  }

  render() {
    return (
      <>
        <div className={style.pdf_wrap}>
          <div className={style.pdf_viewer}>
            <div className={style.pdf_filename_btn}>
              <p className={style.filename}>{this.props.location.state.origin_filename}</p>
              <button onClick={this.downPDFFile}>download</button>
            </div>
            <div className={style.pdf_viewer_section}>
            <div><iframe width='1000px' height='1000px' src={this.state.pdfSrc}/>
            </div>
            </div>
          </div>
        </div>
      </>
    );
  }
}


//useLocation, useNaviagion, useParams를 사용하기 위해 클래스를 Wrap
//클래스에서는 위와 같은 함수를 사용하지 못함
const withWrapper = (Component) => (props) => {
  const history = useNavigate();
  const location = useLocation();
  const params = useParams(); 
  return <Component params={params} history={history} location={location} {...props} />;
};

export default withWrapper(PDFViewer)
//export default PDFviewer;


