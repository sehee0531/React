import React, { Component } from "react";
import { Link } from "react-router-dom";
import { Alert, Button } from "react-bootstrap";

import Constant from "../../util/constant_variables";
import WebServiceManager from "../../util/webservice_manager";

import style from "../../scss/modal/m_project.module.scss";
import cn from "classnames";
import { RiDeleteBinLine } from "react-icons/ri";
import { GrClose } from "react-icons/gr";


//props - ({ index, data, toggleModal })
class DetailPopup extends Component {

  constructor(props) {
    super(props);

    this.state = {
      show: false
    };
  }

  deleteButtonListener = () => {
    console.log('delete');
    this.setState({show:false});
    this.callDeleteProjectWebService().then((response) => {
      console.log(response);
      this.props.deleteListener();
    });        
  }

  async callDeleteProjectWebService() {
    let manager = new WebServiceManager(Constant.serviceURL+"/deleteproject/"+this.props.item.id);
    let response = await manager.start();
    if(response.ok)
      return response.json();
  }

  render() {
    const item = this.props.item;

    return (
      <>
        <div className={style.modal_bg}>
          <div className={cn(style.modal_div, style.m_pro_detail)}>
            <div className={style.m_pro_closebtn}>
              <button onClick={this.props.cancelListener}>
                <GrClose />
              </button>
            </div>

            <div className={style.m_pro_div}>
              <div className={style.m_pro_filename}>
                <p>파일명</p>
                <p>{item.origin_filename}</p>
              </div>

              <div className={style.m_pro_filedetails}>
                <table
                  className={style.m_pro_filedetails_table}
                  cellPadding="0"
                  cellSpacing="0"
                >
                  <thead>
                    <tr>
                      <th>제조사</th>
                      <td>{item.maker}</td>
                    </tr>
                  </thead>
                  <tbody>
                    <tr>
                      <th>파워트레인 사양</th>
                      <td>{item.power}</td>
                    </tr>
                    <tr>
                      <th>지역</th>
                      <td>{item.area}</td>
                    </tr>
                    <tr>
                      <th>등록인</th>
                      <td>{item.register_name}</td>
                    </tr>
                    <tr>
                      <th>등록일</th>
                      <td>{item.register_date}</td>
                    </tr>
                  </tbody>
                </table>
              </div>

              <div className={style.m_pro_viewerbtn}>
                <Link to={'/pdfviewer'} state={item}>
                  <button>PDF 뷰어로 이동</button>
                </Link>
                <button title="프로젝트 삭제" onClick={()=>this.setState({show:true})}>
                  <RiDeleteBinLine />
                </button>
              </div>
            </div>
          </div>
        </div>

        <Alert className={style.a_pro_alert} show={this.state.show} variant="warning">
          <div className={style.a_pro_alerttitle}>
            <p>프로젝트를 삭제하시겠습니까?</p>
            <button onClick={()=>this.setState({show:false})}>
              <GrClose />
            </button>
          </div>

          <Button variant="outline-warning" onClick={this.deleteButtonListener}>삭제</Button>
        </Alert>
      </>
    );
  }
}


export default DetailPopup;
