import React, { Component } from "react";

import WebServiceManager from "../../util/webservice_manager";

import style from "../../scss/modal/m_project.module.scss";
import cn from "classnames";
import { GrClose } from "react-icons/gr";
import Constant from "../../util/constant_variables";

class ValidatePopup extends Component {
  constructor(props) {
    super(props);
  }

  addProject=()=> {
    console.log('send server: ',this.props.data);
    this.callAddProjectWebService().then((response) => {
      console.log(response);
      this.props.okListener();
    });
    
  }

  async callAddProjectWebService() {
    let manager = new WebServiceManager(Constant.serviceURL+"/addproject","post",this.errorListener);
    manager.addFormData("data",{maker:this.props.data.maker,power:this.props.data.power,area:this.props.data.area});
    manager.addBinaryData("file1",this.props.data.file);
    let response = await manager.start();
    if(response.ok)
      return response.json();
  }

  render() {
    return (
      <>
        <div className={style.modal_bg}>
          <div className={cn(style.modal_div, style.m_pro_add)}>
            <div className={style.m_pro_menubar}>
              <p>프로젝트 추가</p>
              <button onClick={this.props.cancelListener}>
                <GrClose />
              </button>
            </div>

            <div className={style.m_pro_contents}>
              <p>
                ** 생성하고자 하는 프로젝트와 PDF파일명이 일치하는지 확인해주세요.
              </p>
              <div className={cn(style.m_pro_select, style.m_pro_manufacture)}>
                <label>제조사</label>
                <input type="text" placeholder={this.props.data.maker} />
              </div>
              <div className={cn(style.m_pro_select, style.m_pro_powerspec)}>
                <label>파워트레인 사양</label>
                <input type="text" placeholder={this.props.data.power} />
              </div>
              <div className={cn(style.m_pro_select, style.m_pro_location)}>
                <label>지역</label>
                <input type="text" placeholder={this.props.data.area} />
              </div>
              <div className={cn(style.m_pro_select, style.m_pro_addfile)}>
                <label>파일 첨부</label>
                <input type="text" placeholder={this.props.data.file.name} />
              </div>

              <div className={cn(style.m_pro_btn, style.m_pro_checkbtn)}>
                <button onClick={this.addProject}>확인</button>
                <button onClick={this.props.cancelListener}>수정</button>
              </div>
            </div>
          </div>
        </div>
      </>
    );
  }
}
export default ValidatePopup;
