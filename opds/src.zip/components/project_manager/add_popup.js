import React, { Component } from "react";

import Constant from "../../util/constant_variables";

import style from "../../scss/modal/m_project.module.scss";
import cn from "classnames";
import { GrClose } from "react-icons/gr";



class AddPopup extends Component {
  constructor(props) {
    super(props);

    this.makers=Constant.getMakers();
    this.powers=Constant.getPowerTrains();
    this.areas=Constant.getAreas();

    this.state={
      maker:this.makers[1].value,
      power:this.powers[1].value,
      area:this.areas[1].value,
      file:null
    };
  }

  passNextStep=(e)=>{
    if(this.state.file===null) {
      alert('파일을 선택하세요...');
      e.preventDefault();
    }
    else {
      const okListener = this.props.okListener.bind();
      console.log('add project value: ',this.state);
      okListener(this.state);
    }
  }

  render() {
    return (
      <>
        <div className={style.modal_bg}>
          <div className={cn(style.modal_div, style.m_pro_add)}>
            <div className={style.m_pro_menubar}>
              <p>프로젝트 추가</p>
              <button onClick={this.props.cancelListener}>
                <GrClose />
              </button>
            </div>

            <div className={style.m_pro_contents}>
              <div className={cn(style.m_pro_select, style.m_pro_manufacture)}>
                <label>제조사</label>
                <select
                  value={this.state.maker}
                  onChange={(e) => this.setState({maker:e.target.value})}>
                  {this.makers.slice(1,this.makers.length).map((item,i) => <option value={item.value} key={i}>{item.title}</option>)}
                </select>
              </div>
              <div className={cn(style.m_pro_select, style.m_pro_powerspec)}>
                <label>파워트레인 사양</label>
                <select
                  value={this.state.power}
                  onChange={(e) => this.setState({power:e.target.value})}>
                  {this.powers.slice(1,this.powers.length).map((item,i) => <option value={item.value} key={i}>{item.title}</option>)}
                </select>
              </div>
              <div className={cn(style.m_pro_select, style.m_pro_location)}>
                <label>지역</label>
                <select
                  value={this.state.area}
                  onChange={(e) => this.setState({area:e.target.value})}>
                  {this.areas.slice(1,this.areas.length).map((item,i) => <option value={item.value} key={i}>{item.title}</option>)}
                </select>
              </div>
              <div className={cn(style.m_pro_select, style.m_pro_addfile)}>
                <label>파일 첨부</label>
                <input type="file" onChange={(e)=>this.setState({file:e.target.files[0]})}/>
              </div>

              <div className={style.m_pro_btn}>
                <button onClick={this.passNextStep}>다음</button>
              </div>
            </div>
          </div>
        </div>
      </>
    );
  }
}
export default AddPopup;
