import React, { Component } from "react";

import style from "../../scss/modal/m_memo.module.scss";
import cn from "classnames";
import { GrClose } from "react-icons/gr";

//props - { toggleModal }
class SendMemo extends Component {
  constructor(props) {
    super(props);
  }

  render() {
    return (
      <>
        <div className={style.modal_bg}>
          <div className={cn(style.modal_div, style.m_memo_send)}>
            <div className={style.m_memo_menubar}>
              <p>MEMO 전송</p>
              <button onClick={this.props.toggleModal}>
                <GrClose />
              </button>
            </div>

            <div className={cn(style.m_memo_box, style.m_memo_sendbox)}>
              <div className={cn(style.m_memo_pinput, style.m_memo_title)}>
                <p>제목</p>
                <input type="text" placeholder="제목을 입력해주세요" />
              </div>

              <div className={cn(style.m_memo_pinput, style.m_memo_content)}>
                <p>내용</p>
                <textarea placeholder="내용을 입력해주세요"></textarea>
              </div>
            </div>

            <div className={cn(style.m_memo_btn, style.m_memo_sendbtn)}>
              <button>전송</button>
            </div>
          </div>
        </div>
      </>
    );
  }
}
export default SendMemo;
