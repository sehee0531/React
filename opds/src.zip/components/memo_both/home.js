import React, { Component } from "react";

import style from "../../scss/Memo.module.scss";
import cn from "classnames";
import { Tab, Tabs, TabList, TabPanel } from "react-tabs";
import { Alert, Button } from "react-bootstrap";

import { FiPlus, FiCheck } from "react-icons/fi";
import { IoMdClose } from "react-icons/io";
import { BiMailSend } from "react-icons/bi";

import SendMemo from "./send_popup";
import ViewMemo from "./view_popup";

class MemoBoth extends Component {
  constructor(props) {
    super(props);

    this.state = {
      showMemoModal: false,
      showViewerModal: false,
      show: false, //alert?
    };
  }
  // Memo send 모달
  SendModal = () => {
    this.setState({
      showMemoModal: !this.state.showMemoModal,
    });
  };

  // Memo viewer 모달
  ViewerModal = () => {
    console.log("click");
    this.setState(
      {
        showViewerModal: !this.state.showViewerModal,
      },
      () => {
        console.log(this.state.showViewerModal);
      }
    );
  };
  showAlertFunc = (param) => {
    this.setState({
      show: param,
    });
  };
  render() {
    return (
      <>
        <div className={cn(style.memoboth_wrap)}>
          <div className={cn(style.memoboth_check)}>
            <Tabs>
              <TabList className={cn(style.memoboth_tab_ul)}>
                <Tab>전체</Tab>
                <Tab>미확인</Tab>
                <Tab>확인</Tab>
              </TabList>

              <TabPanel>
                <div className={style.memoboth_tables}>
                  <div className={style.memoboth_table_fix_div}>
                    <table
                      className={cn(
                        style.memoboth_table_fix,
                        style.memoboth_table_fix_check
                      )}
                      cellPadding="0"
                      cellSpacing="0"
                    >
                      <thead>
                        <tr>
                          <th>연번</th>
                          <th>제목</th>
                          <th>등록인</th>
                          <th>등록 날짜</th>
                          <th>상세</th>
                          <th>확인</th>
                          <th>삭제</th>
                        </tr>
                      </thead>
                    </table>
                  </div>
                  <div className={style.memoboth_table_scroll_div}>
                    <table
                      className={cn(
                        style.memoboth_table_scroll,
                        style.memoboth_table_scroll_check
                      )}
                      cellPadding="0"
                      cellSpacing="0"
                    >
                      <tbody>
                        <tr>
                          <td>1</td>
                          <td>DB 7번 내용 수정 부탁 드립니다.</td>
                          <td>매니저 1</td>
                          <td>2022-01-05</td>
                          <td>
                            <button
                              onClick={() => this.ViewerModal()}
                              className={style.memoboth_table_scroll_detailbtn}
                            >
                              <FiPlus />
                            </button>
                          </td>
                          <td>
                            <button
                              className={style.memoboth_table_scroll_checkbtn}
                            >
                              <FiCheck />
                              {/* 클릭 했을 때 아이콘 나와야함 */}
                            </button>
                          </td>
                          <td>
                            <button
                              title="메모 삭제"
                              onClick={() => this.showAlertFunc(true)}
                            >
                              <IoMdClose />
                            </button>
                          </td>
                        </tr>
                        {/* row end */}
                        <tr>
                          <td>2</td>
                          <td>DB 7번 내용 수정 부탁 드립니다.</td>
                          <td>매니저 1</td>
                          <td>2022-01-05</td>
                          <td>
                            <button
                              onClick={() => this.ViewerModal()}
                              className={style.memoboth_table_scroll_detailbtn}
                            >
                              <FiPlus />
                            </button>
                          </td>
                          <td>
                            <button
                              className={style.memoboth_table_scroll_checkbtn}
                            >
                              <FiCheck />
                              {/* 클릭 했을 때 아이콘 나와야함 */}
                            </button>
                          </td>
                          <td>
                            <button
                              title="메모 삭제"
                              onClick={() => this.showAlertFunc(true)}
                            >
                              <IoMdClose />
                            </button>
                          </td>
                        </tr>
                        {/* row end */}
                        <tr>
                          <td>3</td>
                          <td>DB 7번 내용 수정 부탁 드립니다.</td>
                          <td>매니저 1</td>
                          <td>2022-01-05</td>
                          <td>
                            <button
                              onClick={() => this.ViewerModal()}
                              className={style.memoboth_table_scroll_detailbtn}
                            >
                              <FiPlus />
                            </button>
                          </td>
                          <td>
                            <button
                              className={style.memoboth_table_scroll_checkbtn}
                            >
                              <FiCheck />
                              {/* 클릭 했을 때 아이콘 나와야함 */}
                            </button>
                          </td>
                          <td>
                            <button
                              title="메모 삭제"
                              onClick={() => this.showAlertFunc(true)}
                            >
                              <IoMdClose />
                            </button>
                          </td>
                        </tr>
                        {/* row end */}
                        <tr>
                          <td>4</td>
                          <td>DB 7번 내용 수정 부탁 드립니다.</td>
                          <td>매니저 1</td>
                          <td>2022-01-05</td>
                          <td>
                            <button
                              onClick={() => this.ViewerModal()}
                              className={style.memoboth_table_scroll_detailbtn}
                            >
                              <FiPlus />
                            </button>
                          </td>
                          <td>
                            <button
                              className={style.memoboth_table_scroll_checkbtn}
                            >
                              <FiCheck />
                              {/* 클릭 했을 때 아이콘 나와야함 */}
                            </button>
                          </td>
                          <td>
                            <button
                              title="메모 삭제"
                              onClick={() => this.showAlertFunc(true)}
                            >
                              <IoMdClose />
                            </button>
                          </td>
                        </tr>
                        {/* row end */}
                        <tr>
                          <td>5</td>
                          <td>DB 7번 내용 수정 부탁 드립니다.</td>
                          <td>매니저 1</td>
                          <td>2022-01-05</td>
                          <td>
                            <button
                              onClick={this.ViewerModal}
                              className={style.memoboth_table_scroll_detailbtn}
                            >
                              <FiPlus />
                            </button>
                          </td>
                          <td>
                            <button
                              className={style.memoboth_table_scroll_checkbtn}
                            >
                              <FiCheck />
                              {/* 클릭 했을 때 아이콘 나와야함 */}
                            </button>
                          </td>
                          <td>
                            <button
                              title="메모 삭제"
                              onClick={() => this.showAlertFunc(true)}
                            >
                              <IoMdClose />
                            </button>
                          </td>
                        </tr>
                        {/* row end */}
                      </tbody>
                    </table>
                  </div>
                  {this.state.showViewerModal && (
                    <ViewMemo toggleModal={this.ViewerModal} />
                  )}
                </div>
              </TabPanel>
              <TabPanel>
                <h2>Any content 2</h2>
              </TabPanel>
              <TabPanel>
                <h2>Any content 3</h2>
              </TabPanel>
            </Tabs>
          </div>
          {/* .memoboth_check end */}
          <div className={style.memoboth_border}></div>

          <div className={cn(style.memoboth_send)}>
            <div className={cn(style.memoboth_h6btn)}>
              <h6>메모 전송 이력</h6>
              <button onClick={this.SendModal}>
                <BiMailSend /> Memo 전송
              </button>
              {this.state.showMemoModal && (
                <SendMemo toggleModal={this.SendModal} />
              )}
            </div>
            <div className={style.memoboth_tables}>
              <div className={style.memoboth_table_fix_div}>
                <table
                  className={style.memoboth_table_fix}
                  cellPadding="0"
                  cellSpacing="0"
                >
                  <thead>
                    <tr>
                      <th>연번</th>
                      <th>제목</th>
                      <th>전송 날짜</th>
                      <th>상세</th>
                    </tr>
                  </thead>
                </table>
              </div>
              <div className={style.memoboth_table_scroll_div}>
                <table
                  className={style.memoboth_table_scroll}
                  cellPadding="0"
                  cellSpacing="0"
                >
                  <tbody>
                    <tr>
                      <td>1</td>
                      <td>DB 7번 내용 수정 부탁 드립니다.</td>
                      <td>2022-01-05</td>
                      <td>
                        <button
                          onClick={this.ViewerModal}
                          className={style.memoboth_table_scroll_detailbtn}
                        >
                          <FiPlus />
                        </button>
                      </td>
                    </tr>
                    {/* row end */}
                    <tr>
                      <td>2</td>
                      <td>DB 7번 내용 수정 부탁 드립니다.</td>
                      <td>2022-01-05</td>
                      <td>
                        <button
                          onClick={this.ViewerModal}
                          className={style.memoboth_table_scroll_detailbtn}
                        >
                          <FiPlus />
                        </button>
                      </td>
                    </tr>
                    {/* row end */}
                    <tr>
                      <td>3</td>
                      <td>DB 7번 내용 수정 부탁 드립니다.</td>
                      <td>2022-01-05</td>
                      <td>
                        <button
                          onClick={this.ViewerModal}
                          className={style.memoboth_table_scroll_detailbtn}
                        >
                          <FiPlus />
                        </button>
                      </td>
                    </tr>
                    {/* row end */}
                  </tbody>
                </table>
              </div>
            </div>
          </div>
          {/* .memo_send end */}
        </div>

        <div className={style.a_memo_bg}>
          <Alert
            className={style.a_memo_alert}
            show={this.state.show}
            variant="warning"
          >
            <div className={style.a_memo_alerttitle}>
              <p>메모를 삭제하시겠습니까?</p>
              <button onClick={() => this.showAlertFunc(false)}>X</button>
            </div>

            <Button variant="outline-warning">삭제</Button>
          </Alert>
        </div>
      </>
    );
  }
}
export default MemoBoth;
