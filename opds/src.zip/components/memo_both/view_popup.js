import React, { Component } from "react";

import style from "../../scss/modal/m_memo.module.scss";
import cn from "classnames";

//props - toggleModal
class ViewMemo extends Component {
  constructor(props) {
    super(props);

  }

  render() {
    return (
      <>
        <div className={style.modal_bg}>
          <div className={cn(style.modal_div, style.m_memo_viewer)}>
            <div className={style.m_memo_menubar}>
              <p>MEMO 전송내역</p> {/* Lv. 2,3 - memo 전송내역 viewer인 경우 */}
              {/* <p>MEMO</p> */} {/* Lv. 1,2 - memo 확인 viewer인 경우 */}
            </div>

            <div className={cn(style.m_memo_box, style.m_memo_viewerbox)}>
              <div className={cn(style.m_memo_pinput, style.m_memo_title)}>
                <p>제목</p>
                <input
                  type="text"
                  placeholder="DB 7번 내용 수정 부탁 드립니다."
                />
              </div>

              <div className={cn(style.m_memo_pinput, style.m_memo_content)}>
                <p>내용</p>
                <textarea readOnly>
                  DB 7번 내용 Fife 에서 Pipe 로 변경 부탁 드립니다.
                </textarea>
              </div>
            </div>

            <div className={style.m_memo_writer}>
              {/* Lv.1 & 2 memo viewer 인 경우 등록인/등록날짜 둘 다 필요 */}
              <div className={cn(style.m_memo_whowhen, style.m_memo_who)}>
                <p>등록인</p>
                <p>매니저 1</p>
              </div>

              {/* Lv.2 & 3 전송내역을 볼 때는 등록날짜만 필요 */}
              <div className={cn(style.m_memo_whowhen, style.m_memo_when)}>
                <p>등록날짜</p>
                <p>2022-01-24-월요일</p>
              </div>
            </div>

            <div className={cn(style.m_memo_btn, style.m_memo_closebtn)}>
              <button onClick={this.props.toggleModal}>닫기</button>
            </div>
          </div>
        </div>
      </>
    );
  }
}

export default ViewMemo;
