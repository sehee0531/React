import React, { Component } from "react";
import { Link } from "react-router-dom";

import Constant from "../../util/constant_variables";
import MyStore from "../../util/redux_store";

import style from "../../scss/AdminHome.module.scss";
import cn from "classnames";



class AdminHome extends Component {
    constructor(props) {
      super(props);
      this.state = {
        itemListCount: [],
        itemList:Constant.getHomeItem()
      };
    }
  
    componentDidMount() {
      this.unsubscribe=MyStore.subscribe(this.onStoreChange);
      this.setState({itemListCount:[12,20,35,45]});  
    }
  
    componentWillUnmount() {
      this.unsubscribe();
    }
  
    onStoreChange=()=> {
      this.setState({itemList:Constant.getHomeItem()});
    }
  
    render() {
      return (
        <>
          <div className={style.admin_wrap}>
            <div className={style.admin_divs}>
            {this.state.itemList.map((content,i) => <LinkListItem contents={content} key={i} count={this.state.itemListCount[i]}/>)}
            </div>
          </div>
        </>
      );
    }
  }
  
  
  //홈화면에 보여질 각 항목 UI
  class LinkListItem extends Component {
    constructor(props) {
      super(props);
    }
  
    render() {
      const content = this.props.contents;
      return (
        <>
          <Link to={content.path}>
            <div className={cn(style.admin_div, content.userSytle)}>
              <ul className={style.admin_divinfo}>
                <li>
                  <p>
                    <img src={content.imageSrc} alt="icon" />
                  </p>
                  <p>{content.title}</p>
                </li>
                <li>
                  <span>{this.props.count}</span>개
                </li>
              </ul>
            </div>
          </Link>
        </>
      );
    }
  }
  
  export default AdminHome;
  