import React, { Component } from "react";
import { Link } from "react-router-dom";

import WebServiceManager from "../../util/webservice_manager";
import MyStore from "../../util/redux_store";
import Constant from "../../util/constant_variables";

import style from "../../scss/Login.module.scss";
import logo from "../../images/login_logo.svg";

class Login extends Component {
  constructor(props) {
    super(props);
    //state 변수
    this.state = {
      id: '',
      pw: '',
      savedID:false,
      autoLogin:false
    };
    MyStore.dispatch({type:"Visit"});
  }

  componentDidMount() {
    if(localStorage.getItem('savedID'))
      this.setState({id:localStorage.getItem('savedID'),savedID:true});
    else
      this.setState({id:'아이디를 입력하세요',savedID:false});

    console.log('saved value: ',this.state);
  }

  inputHandler=(e) => {
    if (e.target.name === 'id') {
      this.setState({
        id: e.target.value
      });
    } else {
      this.setState({
        pw: e.target.value
      });
    }
  }

  checkBoxHandler=(e)=> {
    if(e.target.name==='saveID') {
      this.setState({savedID:e.target.checked});
    }
    else {
      this.setState({autoLogin:e.target.checked});
    }       
    
    console.log('local storage savedID:',localStorage.getItem('savedID'));
    console.log('check box: ',this.state.savedID,this.state.autoLogin);
  }

  submitHandler=(e)=> {  
    console.log('start login process....');
    //아이디 저장을 선택했으면 localStorage에 ID저장 그렇지 않으면 모두 삭제
    if(this.state.savedID===true)
      localStorage.setItem('savedID',this.state.id);
    else
      localStorage.clear();

    if(this.state.id!=='' && this.state.pw!=='') {
      this.callLoginWebService().then((response) => {
        console.log('login message:',response);
        console.log('cookie: ',response.headers);
        if(response.success===1) {
          MyStore.dispatch({type:"Login",data:{level:response.level,userID:response.userID,userName:response.userName}});          
          console.log('login complete MyStore Value:',MyStore.getState());
        }
        else {
          MyStore.dispatch({type:"Logout"});
          e.preventDefault();
          alert('사용자계정 또는 비밀번호가 틀립니다');
        }
      });
    }
    else {
      e.preventDefault();
      alert('아이디와 비밀번호는 필수입니다.');
    }
  }

  async callLoginWebService() {
    let manager = new WebServiceManager(Constant.serviceURL+"/login","post",this.errorEventListener);
    manager.setCredentials('include');
    manager.addFormData("data",{id:this.state.id,pwd:this.state.pw});
    let response = await manager.start();
    console.log('response headers: ',response.headers);
    if(response.ok)
      return response.json();
  }

  errorEventListener=(e) => {    
    alert('네트워크 오류');
    e.preventDefault();
  }

  

  render() {
    console.log('login rendering id: ',localStorage.getItem('savedID'),this.state);
    return (
      <div className={style.login_wrap}>
        <form className={style.login_form}>
          <div className={style.login_top}>
            <div>
              <img src={logo} alt="TLA-logo" />
            </div>
            <p>
              <strong>O</strong>wner's manual&nbsp;
              <strong>P</strong>rohibited text&nbsp;
              <strong>D</strong>etextion&nbsp;
              <strong>S</strong>ystem&nbsp;
            </p>
          </div>

          <div className={style.login_idpw}>
            <ul className={style.login_id}>
              <li>
                <label>ID</label>
              </li>
              <li>
                <input
                  type="text"
                  name="id"
                  placeholder={this.state.id}
                  onChange={this.inputHandler}
                />
              </li>
            </ul>
            <ul className={style.login_pw}>
              <li>
                <label>Password</label>
              </li>
              <li>
                <input
                  type="password"
                  name="pass"
                  placeholder="비밀번호를 입력하세요"
                  onChange={this.inputHandler}
                />
              </li>
            </ul>
          </div>

          <div className={style.login_checkboxes}>
            <ul>
              <li>
                <input type="checkbox" name="saveID" checked={this.state.savedID} onChange={this.checkBoxHandler}/>
                <p>아이디 저장</p>
              </li>
              <li>
                <input type="checkbox" name="autoLogin" onChange={this.checkBoxHandler}/>
                <p>자동 로그인</p>
              </li>
            </ul>
          </div>
          <Link to='/adminhome'>
            <div className={style.login_btn}>
              <button onClick={this.submitHandler}>login</button>
            </div>
          </Link>
        </form>
        {/* .login_form end */}
      </div> /* .login_wrap end */

    );
  }
}

export default Login;
