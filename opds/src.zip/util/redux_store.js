import {createStore} from "redux";

const loginState={isLogin:sessionStorage['isLogin']==='true' ? true:false,level:parseInt(sessionStorage['level']),visitLogin:false};

function reducer (state=loginState, action)  {
    switch(action.type) {
        case "Login":
            sessionStorage['isLogin']='true';
            sessionStorage['level']=String(action.data.level);
            sessionStorage['userID']=action.data.userID;
            sessionStorage['userName']=action.data.userName;
            return {...state, isLogin:true,level:action.data.level, visitLogin:false};
        case "Logout" :
            sessionStorage['isLogin']='false';
            sessionStorage['level']='0';
            sessionStorage['uesrID']='';
            sessionStorage['userName']='';
            return {...state, isLogin:false, level:0, visitLogin:true};
        case "Visit" :
            return {...state, isLogin:state.isLogin, level:state.level, visitLogin:true};
        case "Exit" :
            return {...state, isLogin:state.isLogin, level:state.level, visitLogin:false};
        default:
            return {...state, state};
    }
};

export default createStore(reducer);