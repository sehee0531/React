import MyStore from "./redux_store";

import home from "../images/home.svg";
import folder from "../images/folder02.svg";
import openbook from "../images/open-book.svg";
import usermanage from "../images/profile.svg";
import memo from "../images/sticky-note.svg";
import style from "../scss/AdminHome.module.scss";

class Constant {

    //웹서비스 URL 지정
    static serviceURL="http://192.168.1.6/opdsapi";
    //static serviceURL="http://localhost:5000";
    //static pdfServiceURL="http://192.168.0.36/opds/api2";

    //파이썬 웹서비스 URL지정 (PDF관련)
    //static serviceURL="http://ai.pyunhan.co.kr/opdsapi";
    //static pdfServiceURL="http://ai.pyunhan.co.kr/opds/api2";
    //static pdfServiceURL="http://localhost:4000/opds/api2";


    //로그인 후 사이드 메뉴 항목 리턴
    static getSideMenus() {
        const level = MyStore.getState().level;
        if(level===1)
            return Constant.getLevel1();
        else if(level===2)
            return Constant.getLevel2();
        else return [];
    }

    //로그인 후 홈화면에 보여질 항목 리턴
    static getHomeItem() {
        const level = MyStore.getState().level;
        if(level===1)
            return Constant.getLevel1HomeItem();
        else if(level===2)
            return Constant.getLevel2HomeItem();
        else
            return [];
    }

    //페이지 경로를 key로, 경로에 대한 title 돌려줌
    static getMenuName(key) {
        return Constant.getMenus().get(key).title;
    }

    //페이지 경로를 key로, 경로에 대한 index(각 메뉴에 index를 부여하여 현재 선택된 값 인식)값 돌려줌
    static getMenuActiveIndex(key) {
        const menus = Constant.getMenus();
        if(menus.get(key)!==undefined)
            return Constant.getMenus().get(key).activeIndex;
        return 0;
    }


    //DBList 검색항목 리스트
    static getMakers() {
        return [
            {value:"All",title:"전체"},
            {value:"제네시스",title:"제네시스"},
            {value:"현대자동차",title:"현대자동차"}
        ];
    }

    static getPowerTrains() {
        return [
            {value:"All",title:"전체"},
            {value:"내연기관(가솔린/디젤)",title:"내연기관(가솔린/디젤)"},
            {value:"EV",title:"EV"},
            {value:"HEV",title:"HEV"}
        ];
    }

    static getAreas() {
        return [
            {value:"All",title:"전체"},
            {value:"미국",title:"미국"},
            {value:"유럽",title:"유럽"},
            {value:"영국",title:"영국"},
            {value:"호주",title:"호주"},
            {value:"캐나다",title:"캐나다"},
            {value:"한국",title:"한국"}
        ];
    }
    //DBList 검색항목 리스트 끝











    //로컬 메서드(메뉴 세팅)
    //각 메뉴경로에 대한 title, icon, style 지정
    static getMenus() {
        const menuMap= new Map();
        menuMap.set('/adminhome',{title:'홈',icon:home,userStyle:null,activeIndex:1});
        menuMap.set('/projectmanage',{title:'프로젝트 관리',icon:folder,userStyle:style.admin_projectmanage,activeIndex:2});
        menuMap.set('/dblist',{title:'DB 목록',icon:openbook,userStyle:style.admin_dblist,activeIndex:3});
        menuMap.set('/memo',{title:'메모',icon:memo,userStyle:style.admin_memo,activeIndex:4});
        menuMap.set('/memoboth',{title:'메모',icon:memo,userStyle:style.admin_memo,activeIndex:5});
        menuMap.set('/usermanage',{title:'직원 관리',icon:usermanage,userStyle:style.admin_usermanage,activeIndex:6});
        menuMap.set('/pdfviewer',{title:'PDF파일보기',icon:null,userSytpe:null,activeIndex:7});
        return menuMap;
    }    
   

    //로컬 메서드 (레벨에 따른 사이드 바 메뉴, 사용자 레벨에 따라 다름)
    //배열에 추가하는것만으로 메뉴 만들어짐
    static getLevel1() {
        const items = ['/adminhome','/projectmanage','/dblist','/memo','/usermanage'];
        let menuItems=[];
        for(let i=0;i<items.length;i++) {
            const menu = Constant.getMenus().get(items[i]);
            menuItems.push({path:items[i],activeIndex:menu.activeIndex,imageSrc:menu.icon,title:menu.title});
        }
        return menuItems;
    }

    static getLevel2() {
        const items = ['/adminhome','/projectmanage','/dblist','/memoboth'];
        let menuItems=[];
        for(let i=0;i<items.length;i++) {
            const menu = Constant.getMenus().get(items[i]);
            menuItems.push({path:items[i],activeIndex:menu.activeIndex,imageSrc:menu.icon,title:menu.title});
        }
        return menuItems;
    }

    static getLevel3() {
        const items = ['/adminhome','/projectmanage'];
        let menuItems=[];
        for(let i=0;i<items.length;i++) {
            const menu = Constant.getMenus().get(items[i]);
            menuItems.push({path:items[i],activeIndex:menu.activeIndex,imageSrc:menu.icon,title:menu.title});
        }
        return menuItems;
    }


    //로컬메서드 (로그인 후 홈화면에 보여질 항목. 사용자 레벨에 따라 다름)
    //배열에 추가하는것만으로 메뉴 만들어짐
    static getLevel1HomeItem() {
        const items = ['/projectmanage','/dblist','/memo','/usermanage'];
        let homeItems=[];
        for(let i=0;i<items.length;i++) {
            const menu = Constant.getMenus().get(items[i]);
            homeItems.push({path:items[i],userStyle:menu.userStyle,imageSrc:menu.icon,title:menu.title});
        }
        return homeItems;
    }

    static getLevel2HomeItem() {
        const items = ['/projectmanage','/dblist','/memoboth'];
        let homeItems=[];
        for(let i=0;i<items.length;i++) {
            const menu = Constant.getMenus().get(items[i]);
            homeItems.push({path:items[i],userStyle:menu.userStyle,imageSrc:menu.icon,title:menu.title});
        }
        return homeItems;
    }    
}

export default Constant;