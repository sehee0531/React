import React, { Component } from "react";


//< 1 2 3 4> 와 같이 페이지 표시함
class Pagenation extends Component {
    constructor(props) {
        super(props);         
    }

    render() {
        const {itemCount,itemCountPerPage,currentPage,clickListener} = this.props;
        const pages = Math.ceil(itemCount/itemCountPerPage);

        return (
            <>
                <button onClick={() => clickListener(currentPage - 1)} disabled={currentPage === 1}>&lt;</button>
                {Array(pages).fill().map((_, i) => <Numbering key={i+1} page={i+1} clickListener={clickListener}/>)}
                <button onClick={() => clickListener(currentPage + 1)} disabled={currentPage === pages}>&gt;</button>            
            </>
        );
    }
}

//각 페이지 번호를 어떻게 그릴것인지... 디자인만 바꾸는걸로....
class Numbering extends Component {
    constructor(props) {
        super(props);
    }

    render() {
        return (
            <>
                <button  onClick={() => this.props.clickListener(this.props.page)}>
                    {this.props.page}
                </button>
            </>
        );
    }
}

export default Pagenation;