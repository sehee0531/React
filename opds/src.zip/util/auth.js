import WebServiceManager from "./webservice_manager";
import MyStore from "../ReduxStore/MyStore";

class LoginInfo {

    static checkLogin() {
        LoginInfo.callCheckLoginWebService().then((response) => {
            console.log('login check...',response);
            if(response.success===0) {
                MyStore.dispatch({type:"Logout"});
            }
        });
    }

    static async callCheckLoginWebService() {
        let manager = new WebServiceManager("http://localhost:5000/checklogin");
        manager.setCredentials('include');
        let response = await manager.start();
        if(response.ok)
            return response.json();
    }
}

export default LoginInfo;