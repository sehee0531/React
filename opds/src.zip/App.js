import React, { Component } from "react";
import { BrowserRouter, Route, Routes } from "react-router-dom";
import { Outlet, Navigate } from "react-router-dom";

import MyStore from "./util/redux_store";

import LoginPage from "./pages/login"; /* 로그인 페이지 */
import AdminHomePage from "./pages/admin_home"; /* 관리자 - 홈 화면 */
import ProjectManagerPage from "./pages/project_manager"; /* 프로젝트 관리 / Lv 2-3 홈 화면 */
import PDFViewerPage from "./pages/pdf_viewer"; /* 프로젝트관리 > PDF 뷰어 */
import DBListPage from "./pages/db_list"; /* 데이터 목록 */
import MemoPage from "./pages/memo"; /* Admin, Lv3 메시지 수신 or 전송 only */
import MemoBothPage from "./pages/memo_both"; /* Lv2 메시지 수신, 전송 둘 다 가능 */
import UserManagerPage from "./pages/user_manager"; /* 직원관리 */

/* bootstrap */
import "../node_modules/bootstrap/dist/css/bootstrap.min.css";
/* react-tabs */
import "../node_modules/react-tabs/style/react-tabs.css";
/* 공통 SCSS */
import "./scss/App.module.scss";

class App extends Component {
  constructor(props) {
    super(props);
  }

  render() {
    return (
      <>
       <BrowserRouter basename="/opdshome">
          <Routes>            

            <Route path="/" element={<LoginPage />} />

            <Route path="/adminhome" element={<ConditionRoute path={'/'} originPath={'/adminhome'}/>}>
              <Route path="/adminhome" element={<AdminHomePage/>}/>
            </Route>

            <Route path="/projectmanage" element={<ConditionRoute path={'/'} originPath={'/projectmanage'}/>}>
              <Route path="/projectmanage" element={<ProjectManagerPage/>}/>
            </Route>

            <Route path="/pdfviewer" element={<ConditionRoute path={'/'} originPath={'/pdfviewer'}/>}>
              <Route path="/pdfviewer" element={<PDFViewerPage/>}/>
            </Route>

            <Route path="/dblist" element={<ConditionRoute path={'/'} originPath={'/dblist'}/>}>
              <Route path="/dblist" element={<DBListPage/>}/>
            </Route>

            <Route path="/memo" element={<ConditionRoute path={'/'} originPath={'/memo'}/>}>
              <Route path="/memo" element={<MemoPage/>}/>
            </Route>

            <Route path="/memoboth" element={<ConditionRoute path={'/'} originPath={'/memoboth'}/>}>
              <Route path="/memoboth" element={<MemoBothPage/>}/>
            </Route>
          
            <Route path="/usermanage" element={<ConditionRoute path={'/'} originPath={'/usermanage'}/>}>
              <Route path="/usermanage" element={<UserManagerPage/>}/>
            </Route>

          </Routes>
        </BrowserRouter>
      </>
    );
  }
}


//로그인여부 및 사용자 레벨에 따라 Route 설정(레벨이 1이면 memoboth금지, 2이면 usermanage 금지)
class ConditionRoute extends Component {
  constructor(props) {
      super(props);
      this.state={isLogin:MyStore.getState().isLogin,level:MyStore.getState().level,visitLogin:MyStore.getState().visitLogin};
      console.log('Route Constructor Entered.... MyStroe Values:',MyStore.getState());
      console.log('Route Path:',this.props.originPath);      
  }

  componentDidMount() {
    console.log('Route Mounted....');
    this.unsubscribe=MyStore.subscribe(this.onStoreChange);
  }

  componentWillUnmount() {
    console.log('Route UnMounted....');
    this.unsubscribe();
  }

  onStoreChange=() => {    
    this.setState({isLogin:MyStore.getState().isLogin,level:MyStore.getState().level,visitLogin:MyStore.getState().visitLogin});
  }

  render() {    
    console.log('Route Rendering MyStore isLogin: ',this.state.isLogin);
    console.log('Route Rendering MyStore level: ',this.state.level);
    console.log('Route Rendering MyStore Visit: :',this.state.visitLogin);
    console.log('Route Rendering originPathL ',this.props.originPath);
  
    if(this.state.isLogin===true) {
        if(this.state.level===1 && this.props.originPath==='/memoboth') {
          MyStore.dispatch({type:"Logout"}); 
          console.log('memoboth');
          return <Navigate to={this.props.path}/>;          
        }
        else if(this.state.level===2 && this.props.originPath==='/memo') {
          MyStore.dispatch({type:"Logout"});
          console.log('memo');
          return <Navigate to={this.props.path}/>;
        }
        else if(this.state.level===2 && this.props.originPath==='/usermanage') {
          MyStore.dispatch({type:"Logout"});
          console.log('usermanage');
          return <Navigate to={this.props.path}/>;          
        }
        else {    
          console.log('other');    
          return <Outlet />;
        }
    }    
    else if(this.state.visitLogin===true && this.props.originPath==='/adminhome') {
      MyStore.dispatch({type:"Exit"});
      console.log('Route Rendering visitLogin true ...:',MyStore.getState());
      return <Outlet />
    }
    else if(this.state.visitLogin===false && this.props.originPath==='/adminhome')
      return <Navigate to={this.props.path}/>
    else
      return <Navigate to={this.props.path}/>
  }
}
export default App;
