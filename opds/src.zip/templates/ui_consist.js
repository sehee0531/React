import React, { Component } from "react";

import SideMenuBar from "./side_menu_bar";
import TopLogout from "./top";

import style from "../scss/Template.module.scss";


//화면전체 구성 (왼쪽은 메뉴, 위는 로그아웃 표시)
class Template extends Component {
  constructor(props) {
    super(props);
  }

  render() {
    console.log('template part: ',this.props);
    return (
      <>
        <div className={style.tem_wrap}>
          <SideMenuBar />
          <div className={style.tem_contents}>
            <TopLogout />
            <div className={style.tem_changing}>{this.props.children}</div>
          </div>
        </div>
      </>
    );
  }
}

export default Template;