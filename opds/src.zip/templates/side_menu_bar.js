import React, { Component } from "react";
import { Link, useLocation, useNavigate, useParams } from "react-router-dom";

import Constant from "../util/constant_variables";
import MyStore from "../util/redux_store";

import style from "../scss/SideMenubar.module.scss";
import cn from "classnames";
import logo_w from "../images/tla_logo_white_s.png";
import { IoIosArrowBack, IoIosArrowForward } from "react-icons/io";

//사이드 바 메뉴 구성(왼쪽)
class SideMenuBar extends Component {
    constructor(props) {
        super(props);
        this.state = {
            menuBarItems:Constant.getSideMenus(),
            menuHide: false,
            activeIdx: 0,
        };
    }    

    componentDidMount() {
        this.unsubscribe=MyStore.subscribe(this.onStoreChange);
        console.log('active Index: ',Constant.getMenuActiveIndex(this.props.location.pathname));
        this.setActiveIdx(Constant.getMenuActiveIndex(this.props.location.pathname));
    }

    onStoreChange=() => {            
        this.setState({menuBarItems:Constant.getSideMenus()});
        console.log('Get Side Menu Bar...:',this.state.menuBarItems);
    }

    componentWillUnmount() {
        console.log('Side Menu Bar UnMounted....');
        this.unsubscribe();
    }

    setActiveIdx = (param) => {
        this.setState({
        activeIdx: param
        });
    }

    render() {
        console.log('Side Menu Bar Rendering');
        return (
        <>
            <div
            className={cn(
                style.side_wrap,
                `style.side_wrap ${this.state.menuHide ? style.side_wrap_hide : style.side_wrap}`
            )}
            >
            <div
                className={cn(
                style.side_show,
                `style.side_show ${this.state.menuHide ? style.side_hide : style.side_show}`
                )}
            >
                <div className={style.side_logo}>
                <img src={logo_w} alt="logo" />
                </div>
                <ul className={style.side_opdstext}>
                <li>
                    <span>o</span>wner's manual
                </li>
                <li>
                    <span>p</span>rohibited text
                </li>
                <li>
                    <span>d</span>etextion
                </li>
                <li>
                    <span>s</span>ystem
                </li>
                </ul>

                <ul className={style.side_menulist}>
                {/*로그인 사용자 레벨에 맞는 사이드 바 메뉴 render*/}
                {this.state.menuBarItems.map((content,i) => <SideMenuBarItem contents={content} key={i} activeIdx={this.state.activeIdx}/>)}              
                </ul>
            </div>
            <div className={style.side_hidebtn}>
                <button onClick={() => this.setState({menuHide: !this.state.menuHide})}>
                {this.state.menuHide ? <IoIosArrowForward /> : <IoIosArrowBack />}
                {/* <div className={style.side_r_arrow}></div> */}
                {/* <img src={L_arrow} alt="icon" /> */}
                </button>
            </div>
            </div>
        </>
        );
    }
}

//사이드바에 있는 하나의 메뉴에 대한 항목
class SideMenuBarItem extends Component {
    constructor(props) {
        super(props);
    }

    render() {
        const content = this.props.contents;
        return (
        <>        
            <Link to={content.path}>
            <li className={this.props.activeIdx === content.activeIndex ? style.side_bg : style.side_li}>
                <p>
                <img src={content.imageSrc} alt="icon" />
                </p>
                <p>{content.title}</p>
            </li>
            </Link>        
        </>
        );
    }
}

//useLocation, useNaviagion, useParams를 사용하기 위해 클래스를 Wrap
//클래스에서는 위와 같은 함수를 사용하지 못함
const withWrapper = (Component) => (props) => {
    const history = useNavigate();
    const location = useLocation();
    const params = useParams(); 
    return <Component params={params} history={history} location={location} {...props} />;
};

export default withWrapper(SideMenuBar);
//export default SideMenuBar;