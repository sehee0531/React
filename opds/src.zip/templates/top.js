import React, { Component } from "react";
import { MdLogout } from "react-icons/md";
import { Link, useNavigate, useLocation, useParams } from "react-router-dom";

import WebServiceManager from "../util/webservice_manager";
import Constant from "../util/constant_variables";
import MyStore from "../util/redux_store";

import style from "../scss/TopLogout.module.scss";

//로그아웃 (위)
class TopLogout extends Component {
    constructor(props) {
        super(props);
    }

    logoutClickListener =() => {
        this.callLogoutWebService().then((response) => {
            console.log('loout message:',response);
            if(response.success===1) {           
                MyStore.dispatch({type:"Logout"});
                console.log('lotout MyStore : ',MyStore.getState());
                console.log('logout Session: ',sessionStorage['isLogin'],sessionStorage['level']);
            }
        });
    }

    async callLogoutWebService() {
        let manager = new WebServiceManager(Constant.serviceURL+"/logout","post",this.errorEventListener);
        manager.addFormData("data",{id:sessionStorage['userID']});
        let response = await manager.start();
        if(response.ok)
            return response.json();
    }

    errorEventListener=(e) => {    
        e.preventDefault();
        alert('네트워크 오류');    
    }

    render() {
        console.log('top part: ',this.props);
        console.log('top part2: ',this.props.location);
        console.log('top part3: ',Constant.getMenuName(this.props.location.pathname));
        return (
        <div className={style.top_wrap}>
            <p className={style.top_pagetitle}>{Constant.getMenuName(this.props.location.pathname)}</p>

            <Link to="/">
            <button onClick={this.logoutClickListener} className={style.top_logout}>
                <MdLogout />
            </button>
            </Link>
        </div>
        );
    }
}


//useLocation, useNaviagion, useParams를 사용하기 위해 클래스를 Wrap
//클래스에서는 위와 같은 함수를 사용하지 못함
const withWrapper = (Component) => (props) => {
    const history = useNavigate();
    const location = useLocation();
    const params = useParams(); 
    return <Component params={params} history={history} location={location} {...props} />;
};

export default withWrapper(TopLogout);
//export default TopLogout;