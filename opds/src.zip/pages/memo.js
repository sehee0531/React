import React, { Component } from "react";

import Template from "../templates/ui_consist";
import Memo from "../components/memo/home";

class MemoPage extends Component {
  render() {
    return (
      <>
        <Template>
          <Memo />
        </Template>
      </>
    );
  }
}

export default MemoPage;
