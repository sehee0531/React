import { Component } from "react";

import Template from "../templates/ui_consist";
import Adminhome from "../components/admin_home/home";


class AdminHomePage extends Component {
  render() {
    return (
      <>
        <Template>
          <Adminhome />
        </Template>
      </>
    );
  }
}

export default AdminHomePage;
