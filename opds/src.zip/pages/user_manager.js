import { Component } from "react";

import Template from "../templates/ui_consist";
import UserManager from "../components/user_manager/home";

class UserManagerPage extends Component {
  render() {
    return (
      <>
        <Template>
          <UserManager />
        </Template>
      </>
    );
  }
}

export default UserManagerPage;
