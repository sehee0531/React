import React, { Component } from "react";

import Template from "../templates/ui_consist";
import PDFViewer from "../components/project_manager/pdf_viewer";

class PDFViewerPage extends Component {
  render() {
    return (
      <>
        <Template>
          <PDFViewer />
        </Template>
      </>
    );
  }
}

export default PDFViewerPage;
