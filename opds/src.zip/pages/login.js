import React, { Component } from "react";
import Login from "../components/login/home";

class LoginPage extends Component {
  render() {
    return (
      <>
        <Login />
      </>
    );
  }
}

export default LoginPage;
