import React, { Component } from "react";

import Template from "../templates/ui_consist";
import MemoBoth from "../components/memo_both/home";

class MemoBothPage extends Component {
  render() {
    return (
      <>
        <Template>
          <MemoBoth />
        </Template>
      </>
    );
  }
}

export default MemoBothPage;
