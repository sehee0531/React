import React, { Component } from "react";

import Template from "../templates/ui_consist";
import ProjectManager from "../components/project_manager/home";

class ProjectManagerPage extends Component {
  render() {
    return (
      <>
        <Template>
          <ProjectManager />
        </Template>
      </>
    );
  }
}

export default ProjectManagerPage;
