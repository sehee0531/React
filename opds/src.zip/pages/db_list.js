import React, { Component } from "react";

import Template from "../templates/ui_consist";
import DBList from "../components/dblist/home";

class DBListPage extends Component {
  render() {
    return (
      <>
        <Template>
          <DBList />
        </Template>
      </>
    );
  }
}
export default DBListPage;
