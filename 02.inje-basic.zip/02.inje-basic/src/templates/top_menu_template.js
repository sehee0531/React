import React, { Component } from "react";

class TopMenuTemplate extends Component {
    render() {
        return (
            <div>
                <p>홈페이지 연습</p>
            </div>
        );
    }
}

export default TopMenuTemplate;