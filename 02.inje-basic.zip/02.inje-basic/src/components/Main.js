import React, { Component } from "react";

class Main extends Component {
    render() {
        return(
            <>
            <h3>인제대학교 MDL 프로젝트</h3>
            <h3>React 기반의 프로그래밍을 구조적으로 표준화 하였습니다</h3>
            <h3>향후 개발 시 본 구조를 따라 개발합니다</h3></>
        );
    }
}

export default Main;