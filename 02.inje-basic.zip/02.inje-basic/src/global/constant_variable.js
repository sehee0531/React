export default class Constant {
    static serviceURL = "http://203.241.251.177/car";
}