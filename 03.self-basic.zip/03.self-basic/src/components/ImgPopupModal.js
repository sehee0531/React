import React, { Component } from "react";

class TestModal extends Component {
    constructor(props){
        super(props);
        this.state={content:null}
    }

    
    
    render() {
        return(
            <>
            <div>
            {this.props.sendimg}
            <button onClick={this.props.Oksign}>확인</button>
            <button onClick={this.props.listener}>닫기</button>
            </div>
            </>
        );
    }
}

export default TestModal;