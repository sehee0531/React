import React, { Component } from "react";
import Constant from "../global/constant_variable";
import WebServiceManager from "../util/webservice_manager";
import PlusModal from "./PlusModal";

class GetRepairImage extends Component {
    constructor(props) {
        super(props);
        this.state={repairContents:[]};
    }

    componentDidMount() {
        this.callGetRepairAPI().then((response) => {
            console.log(response);
            this.setState({repairContents:response.goods});
        });
    }

    async callGetRepairAPI() {
        let manager = new WebServiceManager(Constant.serviceURL+"/GetGoods");
        let response = await manager.start();
        if(response.ok)
            return response.json();
        else
            Promise.reject(response);
    }

    render() {
        return(
            <>
            <table>
                <thead>
                    <tr>
                        <th>이름&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;</th>
                        <th>상품명&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;</th>
                        <th>상품설명&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;</th>
                        <th>가격&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;</th>
                        <th>상품사진</th>
                    </tr>
                </thead>                
            </table>

            <table>
                <tbody>
                    {this.state.repairContents.map((item,i)=><GetRepairList item={item} key={i}/>)}
                </tbody>
            </table>
            </>
        );
    }
}

class GetRepairList extends Component {
    constructor(props) {
        super(props);

        this.state={imageURL:null};
        this.state={imageURL2:null};
        this.state={viewModal:false};
    }

    componentDidMount() {
        this.callGetRepairImageAPI().then((response) => {
            this.setState({imageURL:URL.createObjectURL(response)});
        });
        this.callGetRepairImageAPI2().then((response) => {
            this.setState({imageURL2:URL.createObjectURL(response)});
        });
    }

    

    async callGetRepairImageAPI() {
        let manager = new WebServiceManager(Constant.serviceURL+"/GetGoodsImage?id="+this.props.item.id+"&rank=1");
        let response = await manager.start();
        if(response.ok)
            return response.blob();
    }

    async callGetRepairImageAPI2() {
        let manager = new WebServiceManager(Constant.serviceURL+"/GetGoodsImage?id="+this.props.item.id+"&rank=2");
        let response = await manager.start();
        if(response.ok)
            return response.blob();
    }

    render() {
        const item = this.props.item;
        return(
            <tr>
                <td>{item.name}</td>
                <td>{item.title}</td>
                <td>{item.content}</td>
                <td>{item.price}</td>
                <td><img src={this.state.imageURL} width="100px"></img></td>
                <td><img src={this.state.imageURL2} width="100px"></img></td>
                <td><button onClick={()=>{this.setState({viewModal:true})}}>+</button></td>
                {this.state.viewModal && (<PlusModal name={item.name} title={item.title} content={item.content} price={item.price} 
                sendimg={<img src={this.state.imageURL} width="100px"></img>} sendimg2 ={<img src={this.state.imageURL2} width="100px"></img>} listener={()=>this.setState({viewModal:false})}/>)}
            </tr>
            
        )
    }
}

export default GetRepairImage;