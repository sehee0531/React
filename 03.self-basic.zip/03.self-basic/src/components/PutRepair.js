import React, { Component } from "react";
import { Alert, Button } from "react-bootstrap";
import style from "../scss/modal/m_db.module.scss";


import { GrClose } from "react-icons/gr";


import WebServiceManager from "../util/webservice_manager";
import Constant from "../global/constant_variable";

class PutRepair extends Component {

    constructor(props) {
        super(props);

        this.state={
            name:null,
            title:null,
            content:null,
            price:null,
            alertShow:false}
    }

    sendRepair=()=> {
        console.log(this.state);
        this.callPutRepairAPI().then((response) => {
            console.log(response);
            if(response.count>0) {
                this.setState({alertShow:true});
            }
        });
    }

    async callPutRepairAPI() {
        let manager = new WebServiceManager(Constant.serviceURL+"/AddGoods","post");
        manager.addFormData("data",{name:this.state.name,title:this.state.title,content:this.state.content,price:this.state.price});
        let response = await manager.start();
        
        if(response.ok)
            return response.json();  
    }

    render() {
        return(
            <>
            <table cellPadding="0" cellSpacing="10">
                <tbody>
                <tr>
                    <th>name</th><td><input type="text" onChange={(e)=>this.setState({name:e.target.value})}></input></td>
                </tr>
                <tr>
                    <th>title</th><td><input type="text" onChange={(e)=>this.setState({title:e.target.value})}></input></td>
                </tr>
                <tr>
                    <th>content</th><td><input type="text" onChange={(e)=>this.setState({content:e.target.value})}></input></td>
                </tr>
                <tr>
                    <th>price</th><td><input type="text" onChange={(e)=>this.setState({price:e.target.value})}></input></td>
                </tr>
                <tr>
                    
                <div className={style.btn}>
                    <button onClick={this.sendRepair}>전송</button>
                </div></tr>
                
                </tbody>
            </table>    


            <Alert show={this.state.alertShow} variant="success">
                <Alert.Heading>데이터 업로드</Alert.Heading>
                <p>성공적으로 업로드되었습니다.</p>
                <hr />
                <div className="d-flex justify-content-end">
                    <Button onClick={() => this.setState({alertShow:false})} variant="outline-success">확인</Button></div>
            </Alert>        
            
            </>

            
        );
    }
}

export default PutRepair;
