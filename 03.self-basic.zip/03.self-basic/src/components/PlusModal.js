import React, { Component } from "react";

class PlusModal extends Component {
    constructor(props){
        super(props);
    }

    
    render() {
        return(
            <>
            <div>
            {this.props.name}<br></br>
            {this.props.title}<br></br>
            {this.props.content}<br></br>
            {this.props.price}<br></br>
            {this.props.sendimg}<br></br>
            {this.props.sendimg2}

            <button onClick={this.props.listener}>닫기</button>
            </div>
            </>
        );
    }
}

export default PlusModal;