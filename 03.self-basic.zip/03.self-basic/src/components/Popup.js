import React, { Component } from "react";
import TestModal from "./TestModal";
import style from "../scss/modal/m_db.module.scss";

class Popup extends Component {
    constructor(props) {
        super(props);
        this.state={viewModal : false, num : 1 , num2 : 1}
    }

    /*abc=(sum)=>{
        this.setState({viewModal:sum});
    }*/

    test=(name)=>{
        console.log(name);
    }

    render() {
        return(
            <>
            <center>
            
            <div>초기값 1으로 주겠삼<br></br><br></br>
            {this.state.num2} 
            {this.state.viewModal && (<TestModal Oksign={()=>this.setState({num2:this.state.num})} number={this.state.num} listener={()=>this.setState({viewModal:false})} plus={()=>this.setState({num:this.state.num+1})}
            minus={()=>this.setState({num:this.state.num-1})}/>)}
            </div>
            <div className={style.btn}>
                
                <button onClick={()=>{this.setState({viewModal:true})}}>팝업</button>
            </div>
            </center>
            </>
        );
    }
}

export default Popup;