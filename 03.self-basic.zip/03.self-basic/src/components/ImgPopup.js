import React, { Component } from "react";
import iphone from "./아이폰6.jpg";
import iphone2 from "./아이폰.jpg";
import ImgPopupModal from "./ImgPopupModal";

class Main extends Component {

    constructor(props){
        super(props)
        
        this.state={viewModal : false}
    }
    
    

    render() {
        return(
            <>
            <div>파일 추가 & 삭제 연습<br></br>
            <div>
            <button onClick={()=>{this.setState({viewModal:true})}}>추가</button>
            </div>
            <img src = {iphone} width="200px"></img>
            <tr>
                <th>사진1</th>
                <td><input type="file" onChange={(e)=>this.setState({file1:e.target.files[0]})}></input></td>
            </tr>
            
            {this.state.viewModal && (<ImgPopupModal Oksign={()=>this.setState({write2:this.state.content})} sendimg={<img src = {iphone2} width="200px"></img>} listener={()=>this.setState({viewModal:false})}/>)}
            </div>
            </>
        );
    }
}

export default Main;