import React, { Component } from "react";
import iphone from "./아이폰6.jpg";
import iphone2 from "./아이폰.jpg";
import ImgPopupModal from "./ImgPopupModal";

class Main extends Component {

    constructor(props){
        super(props)
        
        this.state={write2:""}
        this.state={viewModal:false, content:"리뷰 달아봐"};
    }
    
    

    render() {
        return(
            <>
            <div>이미지 팝업 연습<br></br>
            <img src = {iphone} width="200px"></img>
            {this.state.write2}
            <tr>
                <th>comment : </th><td><input type="text" onChange={(e)=>this.setState({content:e.target.value})}></input></td>
            </tr>
            {this.state.viewModal && (<ImgPopupModal Oksign={()=>this.setState({write2:this.state.content})} sendimg={<img src = {iphone2} width="200px"></img>} listener={()=>this.setState({viewModal:false})}/>)}
            </div>
            <div>
            <button onClick={()=>{this.setState({viewModal:true})}}>이미지 띄우기</button>
            </div>
            </>
        );
    }
}

export default Main;