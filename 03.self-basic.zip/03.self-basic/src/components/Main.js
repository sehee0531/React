import React, { Component } from "react";

class Main extends Component {
    render() {
        return(
            <>
            <h3>인제대학교 MDL 프로젝트</h3>
            </>
        );
    }
}

export default Main;