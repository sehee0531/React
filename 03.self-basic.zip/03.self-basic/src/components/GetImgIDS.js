import React, { Component ,  useState, useCallback } from "react";
import Constant from "../global/constant_variable";
import WebServiceManager from "../util/webservice_manager";
import Pagenation from "../util/pagenation";
import PlusModal from "./PlusModal";
import { GrClose } from "react-icons/gr";
import style from "../scss/modal/m_db.module.scss";
import combo from "../scss/modal/m_db.module.scss";
import Variables from "../util/constant_variables";
import cn from "classnames";

class GetImgIDS extends Component {
    constructor(props) {
        super(props);

        this.names=Variables.getNames();
        this.itemCountPerPage=7; 
        this.state={
            Contents:[],
            currentPage:1,      // 현재 페이지 (setCurrentPage()에서 변경됨)
            offset:0,         //현재페이지에서 시작할 item index};
            name: this.names[0].value, //이름, 초기값 All
            filteredContents:[], //DBList (디스플레이 용, 필터 적용된)
        };
    }

    //Pagenation에서 몇페이지의 내용을 볼지 선택 (페이지를 선택하면 현재의 페이지에따라 offset 변경)
  setCurrentPage = (page) => {
    let lastOffset = (page-1)*this.itemCountPerPage;
    this.setState({currentPage:page,offset:lastOffset});
  };

    componentDidMount() {
        this.callGetRepairAPI().then((response) => {
            console.log(response);
            this.setState({Contents:response.users});

            this.setState({filteredContents:this.dataFiltering(this.state.name)});
        });
    }

    selectMaker = (value) => {
        console.log('selected data: ',value);
        this.setState({
            name: value,
        });
        this.setState({filteredContents:this.dataFiltering(value,this.state.power,this.state.area)});
        this.setCurrentPage(1);
    };

    dataFiltering=(name)=> {
        let filteredContents=this.state.Contents;
    
        filteredContents=filteredContents.filter((content) => {   
          console.log('maker selected: ',this.names[0].value);
          if(name===this.names[0].value)  
            return true;
          else
            return content.name===name;
        });    
    
        return filteredContents;
    }

    async callGetRepairAPI() {
        let manager = new WebServiceManager(Constant.serviceURL+"/GetUsers");
        let response = await manager.start();
        if(response.ok)
            return response.json();
        else
            Promise.reject(response);
    }

    render() {
        return(
            <>
            <div className={combo.db_wrap}>
          <div className={combo.db_selectbtn}>
            <div className={combo.db_selectoption}>
            <div className={cn(combo.db_selectform, combo.db_manufactor)}>
                <p>name</p>
                <select
                  value={this.state.name}
                  onChange={(e) => this.selectMaker(e.target.value)}>
                  {this.names.map((item,i) => <option value={item.value} key={i}>{item.title}</option>)}                  
                </select>
              </div>
              </div>
              </div>
            </div>
            <table>
                <thead>
                    <tr>
                        <th>id&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;</th>
                        <th>name&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;</th>
                        <th>phone&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;</th>
                        <th>ImgIDS</th>
                    </tr>
                </thead>                
            </table>

            <table>
                <tbody>
                    {this.state.filteredContents.slice(this.state.offset,this.state.offset+this.itemCountPerPage).map((item)=><GetRepairList item={item}/>)}
                </tbody>
            </table>
            <div>
          <Pagenation itemCount={this.state.Contents.length} itemCountPerPage={this.itemCountPerPage} currentPage={this.state.currentPage} clickListener={this.setCurrentPage}/>
        </div>
            </>
        );
    }
}

class GetRepairList extends Component {
    
    constructor(props) {
        super(props);
        this.state={viewModal:false}
    }


    render() {
        const item = this.props.item;
        return(
            <tr>
                <td>{item.id}&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;</td>
                <td>{item.name}&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;</td>
                <td>{item.phone}&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;</td>
                
               &nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;
                <td><div className={style.btn}>
                        <button onClick={()=>{this.setState({viewModal:true})}}>+</button>
                    </div>
                </td>

                {this.state.viewModal &&(<IDsList item={item.imageIDs} listener={()=>this.setState({viewModal:false})}/>)}
                
            </tr>
            
        )
    }
}


class IDsList extends Component{
    constructor(props) {
        super(props);
    }

    
    render(){
        return(
            <tr>
                <div className={style.modal_bg}>
                <div className={cn(style.modal_div, style.m_db_add)}>
                <div className={style.m_db_menubar}>
                        <p>이미지 보기</p> <button onClick={this.props.listener}><GrClose /></button>
                        
                    </div>
                    {this.props.item.map((item,i)=><GetImageList item={item} key={i}/>)}
                   
                
                </div>
                </div>
            </tr>
        )
    }
}

class GetImageList extends Component {
    
    constructor(props) {
        super(props);
        this.state={imageURL:null}
    }

    componentDidMount() {
        this.callGetRepairImageAPI(this.props.item).then((response) => {
            this.setState({imageURL:URL.createObjectURL(response)});
        });
    }
    

    async callGetRepairImageAPI(id) {
        let manager = new WebServiceManager(Constant.serviceURL+"/GetUserImage?id="+id);
        let response = await manager.start();
        if(response.ok)
            return response.blob();
    }
    render(){
        return(
            <td>
                
                <img src={this.state.imageURL} width="100px"></img>
                        
            </td>
        )
    }
}
        
    



export default GetImgIDS;