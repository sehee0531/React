import React, { Component ,  useState, useCallback } from "react";
import Constant from "../global/constant_variable";
import WebServiceManager from "../util/webservice_manager";
import PlusModal from "./PlusModal";
import { GrClose } from "react-icons/gr";
import style from "../scss/Template.module.scss";
import cn from "classnames";

class GetImgIDS extends Component {
    constructor(props) {
        super(props);
        this.state={Contents:[]};
    }

    componentDidMount() {
        this.callGetRepairAPI().then((response) => {
            console.log(response);
            this.setState({Contents:response.users});
        });
    }

    async callGetRepairAPI() {
        let manager = new WebServiceManager(Constant.serviceURL+"/GetUsers");
        let response = await manager.start();
        if(response.ok)
            return response.json();
        else
            Promise.reject(response);
    }

    render() {
        return(
            <>
            <table>
                <thead>
                    <tr>
                        <th>id&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;</th>
                        <th>name&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;</th>
                        <th>phone&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;</th>
                        <th>ImgIDS</th>
                    </tr>
                </thead>                
            </table>

            <table>
                <tbody>
                    {this.state.Contents.map((item)=><GetRepairList item={item}/>)}
                </tbody>
            </table>
            </>
        );
    }
}

class GetRepairList extends Component {
    
    constructor(props) {
        super(props);
        this.state={viewModal:false}
    }


    render() {
        const item = this.props.item;
        return(
            <tr>
                <td>{item.id}&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;</td>
                <td>{item.name}&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;</td>
                <td>{item.phone}&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;</td>
                
                &nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;<button onClick={()=>{this.setState({viewModal:true})}}>+</button>

                {this.state.viewModal &&(<IDsList item={item.imageIDs} listener={()=>this.setState({viewModal:false})}/>)}
                
            </tr>
            
        )
    }
}


class IDsList extends Component{
    constructor(props) {
        super(props);
    }
    render(){
        return(
            <tr>
                <div className={style.modal_bg}>
                <div className={cn(style.modal_div, style.m_db_add)}>
                <div className={style.m_db_menubar}>
                        <p>이미지 보기</p> <button onClick={this.props.listener}><GrClose /></button>
                        
                    </div>
                    {this.props.item.map((item,i)=><GetImageList item={item} key={i}/>)}
                   
                
                </div>
                </div>
            </tr>
        )
    }
}

class GetImageList extends Component {
    
    constructor(props) {
        super(props);
        this.state={imageURL:null}
    }

    componentDidMount() {
        this.callGetRepairImageAPI(this.props.item).then((response) => {
            this.setState({imageURL:URL.createObjectURL(response)});
        });
    }
    

    async callGetRepairImageAPI(id) {
        let manager = new WebServiceManager(Constant.serviceURL+"/GetUserImage?id="+id);
        let response = await manager.start();
        if(response.ok)
            return response.blob();
    }
    render(){
        return(
            <td>
                
                <img src={this.state.imageURL} width="100px"></img>
                        
            </td>
        )
    }
}
        
    



export default GetImgIDS;