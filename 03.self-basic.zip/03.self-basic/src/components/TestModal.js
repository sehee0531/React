import React, { Component } from "react";

class TestModal extends Component {
    constructor(props){
        super(props);
    }
    
    render() {
        return(
            <>
            <div>
            <h3>{this.props.number}</h3>
            <button onClick={this.props.plus}>+</button>
            <button onClick={this.props.minus}>-</button>
            <button onClick={this.props.Oksign}>확인</button>
            <button onClick={this.props.listener}>닫기</button>
            </div>
            </>
        );
    }
}

export default TestModal;