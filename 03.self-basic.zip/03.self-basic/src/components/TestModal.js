import React, { Component } from "react";
import Modal from 'react-modal';
import style from "../scss/Template.module.scss";
class TestModal extends Component {
    constructor(props){
        super(props);
    }
    
    render() {
        return(
            <>
            
            <Modal isOpen={true}>
            <div align="right">
            <button onClick={this.props.listener}>X</button>
            </div>
            <h3>{this.props.number}</h3>
            <div className={style.m_db_btn}>
            <button onClick={this.props.plus}>+</button>
            </div>
            <div className={style.m_db_btn}>
            <button onClick={this.props.minus}>-</button>
            </div>
            
            <tr>
            <div className={style.m_db_btn}>
                <button onClick={this.props.Oksign}>확인</button>
            </div>
            </tr>
            
            </Modal>
            </>
        );
    }
}

export default TestModal;