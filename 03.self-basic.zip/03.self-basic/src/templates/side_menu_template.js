import React, { Component } from "react";
import { Link } from "react-router-dom";

import style from "../scss/SideMenubar.module.scss";

class SideMenuBarTemplate extends Component {
    render() {
        return (
            <div className={style.side_wrap}>
                <li className={style.side_menulist}>
                    <ul>
                    <Link to="/">
                        <p>홈</p>
                    </Link>
                    </ul>
                    <ul>
                    <Link to="/GetGoods">
                        <p> 상품 보기</p>
                    </Link>
                    </ul>
                    <ul>
                    <Link to="/PutRepair">
                        <p>상품 업로드</p>
                    </Link>
                    </ul>
                    <ul>
                    <Link to="/PutFile">
                        <p>파일 업로드</p>
                    </Link>
                    </ul>
                    <ul>
                    <Link to="/GetRepairImage">
                        <p>상품 상세보기(이미지포함)</p>
                    </Link>
                    </ul>
                    <ul>
                    <Link to="/Popup">
                        <p>팝업연습</p>
                    </Link>
                    </ul>
                    <ul>
                    <Link to="/ImgPopup">
                        <p>이미지팝업연습</p>
                    </Link>
                    </ul>
                </li>
            </div>
        );
    }
}

export default SideMenuBarTemplate;