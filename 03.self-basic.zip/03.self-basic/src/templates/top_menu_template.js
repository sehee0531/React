import React, { Component } from "react";

class TopMenuTemplate extends Component {
    render() {
        return (
            <div>
                <center><h1>Sehee Project</h1></center>
            </div>
        );
    }
}

export default TopMenuTemplate;