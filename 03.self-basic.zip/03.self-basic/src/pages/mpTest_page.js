import React, { Component } from "react";

import Template from "../templates/ui_consistis_template";
import MpTest from "../components/MpTest";


class MpTestPage extends Component {
    render() {
        return (
            <>
                <Template>
                    <MpTest />
                </Template>
            </>
        );
    }
}

export default MpTestPage;