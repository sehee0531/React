import React, { Component } from "react";

import Template from "../templates/ui_consistis_template";
import GetGoods from "../components/GetGoods";


class GetGoodsPage extends Component {
    render() {
        return (
          <>
            <Template>
              <GetGoods />
            </Template>
          </>
        );
    }
}

export default GetGoodsPage;
