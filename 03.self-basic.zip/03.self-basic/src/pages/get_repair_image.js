import React, { Component } from "react";

import Template from "../templates/ui_consistis_template";
import GetRepairImage from "../components/GetRepairImage";


class GetRepairImagePage extends Component {
    render() {
        return (
          <>
            <Template>
            <center><GetRepairImage /></center>
            </Template>
          </>
        );
    }
}

export default GetRepairImagePage;
