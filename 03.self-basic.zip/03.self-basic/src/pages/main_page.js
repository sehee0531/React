import React, { Component } from "react";

import Template from "../templates/ui_consistis_template";
import Main from "../components/Main";
import GetGoods from "../components/GetGoods";

class MainPage extends Component {
    render() {
        return (
            <>
                <Template>
                    <Main/><GetGoods />
                </Template>
            </>
        );
    }
}

export default MainPage;