import React, { Component } from "react";

import Template from "../templates/ui_consistis_template";
import ImgPopup from "../components/ImgPopup";


class PopupPage extends Component {
    render() {
        return (
            <>
                <Template>
                    <ImgPopup />
                </Template>
            </>
        );
    }
}

export default PopupPage;